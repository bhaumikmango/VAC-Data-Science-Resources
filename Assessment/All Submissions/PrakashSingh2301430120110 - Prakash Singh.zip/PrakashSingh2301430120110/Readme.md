Air Quality Prediction Dashboard

A Streamlit web application for exploring air quality data and predicting PM2.5 levels using machine learning.

Core Features

Interactive Visualizations:
Explore air quality data through maps, time-series charts, and histograms powered by Plotly.

ML-Based Predictions:
Predict PM2.5 concentrations using a pre-trained machine learning model based on user-defined input criteria.

Dynamic Filtering:
Filter and compare data by City and Year for deeper insights.

Setup and Installation

Clone the Repository
Use Git to clone the project and navigate into the directory.

Install Dependencies
Install all required Python libraries listed in requirements.txt.

Ensure Project Structure
The project should contain the following folders and files:

app/app.py

data/air_quality_global.csv

models/air_quality_model.pkl

requirements.txt

README.md

Run the Application
From the project’s root directory, execute:
streamlit run app/app.py

Model Information

The PM2.5 prediction model is trained on global air quality datasets. It uses key environmental parameters such as temperature, humidity, and AQI components to forecast particulate matter levels.

Data Source

The dataset air_quality_global.csv should contain air quality measurements across multiple cities and years. Ensure the data format matches the model’s input schema.

Tech Stack

Frontend: Streamlit (Python)

Visualization: Plotly

Modeling: Scikit-learn / Pickle model

Data Handling: Pandas, NumPy

Author

Prakash Singh
praksh26singh2@gmail.com
