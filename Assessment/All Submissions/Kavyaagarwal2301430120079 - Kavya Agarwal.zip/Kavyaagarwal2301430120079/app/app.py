import streamlit as st
import pandas as pd
import numpy as np
import pickle

# --- 1. Model and Feature Setup ---

# Corrected relative path: go up one level (..) to the root and then into models/
MODEL_PATH = 'models/air_quality_model.pkl'

# Define the features (in the exact order used during training)
# This fulfills the requirement of making features "inbuilt".
feature_names = ['year', 'pm25_ugm3', 'no2_ugm3']

try:
    # Load the trained model using the correct relative path
    with open(MODEL_PATH, 'rb') as file:
        model = pickle.load(file)

except FileNotFoundError:
    st.error(f"🚨 Model file not found! Please check the path: '{MODEL_PATH}'.")
    st.stop()
except Exception as e:
    st.error(f"Error loading model: {e}")
    st.stop()

# --- 2. Streamlit UI Configuration ---

st.set_page_config(page_title="Global Air Quality Predictor 💨", layout="centered")

st.title("Air Quality Prediction Web App")
st.markdown("Enter the parameters below to predict the **Air Quality** status (Good, Moderate, or Poor).")
st.markdown("---")

# --- 3. User Input Form ---

with st.form("prediction_form"):
    st.subheader("Location & Time")

    # Inputs collected as requested (Country/State are not model features)
    country = st.text_input("Country", placeholder="e.g., USA")
    state_or_city = st.text_input("State/City", placeholder="e.g., New York")
    
    # Feature 1: year
    year = st.number_input("Year", min_value=1990, max_value=2100, value=2025, step=1, help="Year of measurement.")

    st.subheader("Pollutant Concentrations ($\mu g/m^3$)")

    # Feature 2: pm25_ugm3
    pm25_ugm3 = st.number_input(
        "PM2.5 concentration",
        min_value=0.0,
        value=25.0,
        step=0.1,
        help="Particulate Matter 2.5."
    )

    # Feature 3: no2_ugm3
    no2_ugm3 = st.number_input(
        "NO2 concentration",
        min_value=0.0,
        value=35.0,
        step=0.1,
        help="Nitrogen Dioxide."
    )

    st.markdown("---")
    submitted = st.form_submit_button("Predict Air Quality")

# --- 4. Prediction Logic and Output ---

if submitted:
    # 1. Prepare input data
    # Use the hardcoded feature_names list to ensure correct order
    input_data = pd.DataFrame(
        [[year, pm25_ugm3, no2_ugm3]],
        columns=feature_names
    )

    # 2. Make prediction
    prediction = model.predict(input_data)[0]
    probas = model.predict_proba(input_data)[0]
    confidence = np.max(probas) * 100

    # 3. Display result
    st.subheader("Prediction Result")

    if prediction == 'Good':
        st.success(f"Predicted Air Quality: **{prediction}** ✅")
        st.balloons()
    elif prediction == 'Moderate':
        st.warning(f"Predicted Air Quality: **{prediction}** ⚠️")
    else: # Poor
        st.error(f"Predicted Air Quality: **{prediction}** ❌")

    st.markdown(f"Model Confidence: **{confidence:.2f}%**")

    # 4. Detailed probabilities
    st.caption("Detailed Class Probabilities:")
    proba_df = pd.DataFrame(
        {'Class': model.classes_, 'Probability': probas * 100}
    ).sort_values('Probability', ascending=False)
    proba_df['Probability'] = proba_df['Probability'].map('{:.2f}%'.format)
    st.dataframe(proba_df, hide_index=True, use_container_width=True)