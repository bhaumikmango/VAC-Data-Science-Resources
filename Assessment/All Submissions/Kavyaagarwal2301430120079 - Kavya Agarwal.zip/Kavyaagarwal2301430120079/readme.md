Air Quality Prediction Dashboard

A Streamlit application for air quality data exploration and PM2.5 prediction.

Core Features

Visualization: Interactive Maps, Time Series, and Histograms (Plotly).

Prediction: ML-based PM2.5 prediction via user input criteria.

Filtering: Dynamic filtering of visualizations by City and Year.

Setup & Run

Dependencies: Install libraries listed in requirements.txt.

Structure: Ensure files are in the correct folders:

data/: requires air_quality_global.csv

models/: requires air_quality_model.pkl

Run: Execute streamlit run app/app.py from the project's root folder.