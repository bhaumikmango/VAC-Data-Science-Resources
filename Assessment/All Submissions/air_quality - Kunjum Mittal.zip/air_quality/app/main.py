import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
import joblib
import json
import os
from datetime import datetime

# Page configuration
st.set_page_config(
    page_title="Urban Air Quality Analysis",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load data and models with error handling
@st.cache_data
def load_data():
    try:
        # Try multiple possible file paths
        possible_paths = [
            'data/air_quality_global.csv',
            '../data/air_quality_global.csv',
            './data/air_quality_global.csv'
        ]
        
        for file_path in possible_paths:
            if os.path.exists(file_path):
                df = pd.read_csv(file_path)
                return df
        
        # If no file found, create demo data
        return create_demo_data()
        
    except Exception as e:
        return create_demo_data()

def create_demo_data():
    """Create demo data if real data is unavailable"""
    np.random.seed(42)
    cities = ['New York', 'London', 'Tokyo', 'Delhi', 'Beijing', 'Paris', 'Sydney']
    countries = ['USA', 'UK', 'Japan', 'India', 'China', 'France', 'Australia']
    
    data = []
    for i in range(1000):
        city_idx = i % len(cities)
        data.append({
            'city': cities[city_idx],
            'country': countries[city_idx],
            'latitude': np.random.uniform(-90, 90),
            'longitude': np.random.uniform(-180, 180),
            'year': np.random.randint(2010, 2024),
            'month': np.random.randint(1, 13),
            'pm25_ugm3': np.random.uniform(10, 150),
            'no2_ugm3': np.random.uniform(20, 100)
        })
    
    return pd.DataFrame(data)

@st.cache_data
def load_metadata():
    """Load metadata with error handling"""
    try:
        possible_paths = [
            'data/metadata.json',
            '../data/metadata.json',
            './data/metadata.json'
        ]
        
        for file_path in possible_paths:
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    return json.load(f)
        
        # Return default metadata if file not found
        return {
            "dataset_name": "Urban Air Quality Dataset",
            "version": "1.0",
            "creation_date": "2024-01-01",
            "total_records": "1000",
            "geographic_coverage": "Global",
            "temporal_coverage": "2010-2023",
            "data_sources": {"default": "Demo data"},
            "data_quality_notes": ["Demo data for testing"],
            "usage_recommendations": ["For demonstration purposes"],
            "citation": "Demo data",
            "license": "CC0",
            "contact": "Not specified"
        }
        
    except Exception as e:
        return {}

@st.cache_resource
def load_model():
    """Load model with error handling"""
    try:
        possible_paths = [
            'models/air_quality_model_tuned.pkl',
            '../models/air_quality_model_tuned.pkl',
            'models/air_quality_model.pkl',
            '../models/air_quality_model.pkl'
        ]
        
        for model_path in possible_paths:
            if os.path.exists(model_path):
                return joblib.load(model_path)
        
        return None
        
    except Exception as e:
        return None

# Load resources
df = load_data()
metadata = load_metadata()
model_artifacts = load_model()

# App title
st.title("🌍 Urban Air Quality Analysis Dashboard")
st.markdown("Explore air quality data and predict PM2.5 levels across global cities")

# Sidebar
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Data Explorer", "Model Predictor", "About & Metadata"])

if page == "Data Explorer":
    st.header("📊 Data Explorer")
    
    # Show basic dataset info
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Records", len(df))
    with col2:
        st.metric("Cities", df['city'].nunique())
    with col3:
        st.metric("Countries", df['country'].nunique())
    
    # Filters
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        countries = ['All'] + sorted(df['country'].unique().tolist())
        selected_country = st.selectbox("Select Country", countries)
    
    with col2:
        # Filter cities based on selected country
        if selected_country != 'All':
            available_cities = ['All'] + sorted(df[df['country'] == selected_country]['city'].unique().tolist())
        else:
            available_cities = ['All'] + sorted(df['city'].unique().tolist())
        selected_city = st.selectbox("Select City", available_cities)
    
    with col3:
        years = ['All'] + sorted(df['year'].unique().tolist())
        selected_year = st.selectbox("Select Year", years)
    
    with col4:
        months = ['All'] + list(range(1, 13))
        selected_month = st.selectbox("Select Month", months)
    
    # Filter data
    filtered_df = df.copy()
    if selected_country != 'All':
        filtered_df = filtered_df[filtered_df['country'] == selected_country]
    if selected_city != 'All':
        filtered_df = filtered_df[filtered_df['city'] == selected_city]
    if selected_year != 'All':
        filtered_df = filtered_df[filtered_df['year'] == selected_year]
    if selected_month != 'All':
        filtered_df = filtered_df[filtered_df['month'] == selected_month]
    
    # Display filtered data info
    st.subheader(f"Filtered Data ({len(filtered_df)} records)")
    
    if not filtered_df.empty:
        st.dataframe(filtered_df, use_container_width=True)
        
        # Visualizations
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("PM2.5 Distribution")
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.histplot(filtered_df['pm25_ugm3'].dropna(), kde=True, ax=ax)
            ax.set_xlabel('PM2.5 (μg/m³)')
            ax.set_ylabel('Frequency')
            ax.set_title(f'PM2.5 Distribution (n={len(filtered_df)})')
            st.pyplot(fig)
        
        with col2:
            st.subheader("NO2 Distribution")
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.histplot(filtered_df['no2_ugm3'].dropna(), kde=True, ax=ax)
            ax.set_xlabel('NO2 (μg/m³)')
            ax.set_ylabel('Frequency')
            ax.set_title(f'NO2 Distribution (n={len(filtered_df)})')
            st.pyplot(fig)
        
        # Time series
        st.subheader("Temporal Trends")
        time_series = filtered_df.groupby(['year', 'month'])[['pm25_ugm3', 'no2_ugm3']].mean().reset_index()
        time_series['date'] = pd.to_datetime(time_series['year'].astype(str) + '-' + time_series['month'].astype(str) + '-01')
        
        fig = px.line(time_series, x='date', y=['pm25_ugm3', 'no2_ugm3'],
                     title='Air Quality Trends Over Time',
                     labels={'value': 'Concentration (μg/m³)', 'variable': 'Pollutant'})
        st.plotly_chart(fig, use_container_width=True)
        
        # Geographic visualization
        st.subheader("Geographic Distribution")
        fig = px.scatter_geo(filtered_df, 
                            lat='latitude', 
                            lon='longitude',
                            color='pm25_ugm3',
                            size='pm25_ugm3',
                            hover_name='city',
                            hover_data=['country', 'pm25_ugm3', 'no2_ugm3'],
                            title='PM2.5 Levels by Location',
                            color_continuous_scale='viridis')
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("No data available for the selected filters.")

elif page == "Model Predictor":
    st.header("🤖 PM2.5 Prediction Model")
    
    if model_artifacts is None:
        st.error("No trained model available. Please run the Jupyter notebook first to train the model.")
        st.info("To enable predictions, run: `jupyter notebook notebooks/EDA_and_Modeling.ipynb`")
    else:
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Make a Prediction")
            
            # Input features
            city = st.selectbox("City", sorted(df['city'].unique()))
            country = st.selectbox("Country", sorted(df['country'].unique()))
            year = st.slider("Year", 2000, 2025, 2023)
            month = st.slider("Month", 1, 12, 6)
            
            # Get coordinates for selected city
            city_data = df[df['city'] == city].iloc[0]
            latitude = st.number_input("Latitude", value=float(city_data['latitude']))
            longitude = st.number_input("Longitude", value=float(city_data['longitude']))
            
            if st.button("Predict PM2.5"):
                # Prepare input data
                input_data = {
                    'city': city,
                    'country': country,
                    'year': year,
                    'month': month,
                    'latitude': latitude,
                    'longitude': longitude,
                    'measurement_method': 'default',
                    'data_source': 'default'
                }
                
                # Make prediction
                try:
                    model = model_artifacts['model']
                    scaler = model_artifacts['scaler']
                    imputer = model_artifacts['imputer']
                    label_encoders = model_artifacts['label_encoders']
                    feature_columns = model_artifacts['feature_columns']
                    
                    # Preprocess input
                    input_processed = {}
                    for col in feature_columns:
                        if '_encoded' in col:
                            original_col = col.replace('_encoded', '')
                            if original_col in label_encoders:
                                input_processed[col] = label_encoders[original_col].transform([input_data[original_col]])[0]
                        else:
                            input_processed[col] = input_data[col]
                    
                    # Create feature array
                    feature_array = np.array([[input_processed[col] for col in feature_columns]])
                    
                    # Impute and scale
                    feature_array_imputed = imputer.transform(feature_array)
                    feature_array_scaled = scaler.transform(feature_array_imputed)
                    
                    # Make prediction
                    prediction = model.predict(feature_array_scaled)[0]
                    
                    st.success(f"Predicted PM2.5 Level: {prediction:.2f} μg/m³")
                    
                    # Interpretation
                    st.subheader("Prediction Interpretation")
                    st.write(f"The model predicts a PM2.5 level of **{prediction:.2f} μg/m³** for {city} in {month}/{year}.")
                    
                    # Health impact context
                    if prediction < 12:
                        st.info("✅ **Good**: PM2.5 level is within WHO recommended guidelines (< 12 μg/m³)")
                    elif prediction < 35:
                        st.warning("⚠️ **Moderate**: PM2.5 level exceeds WHO guidelines but is below unsafe levels")
                    else:
                        st.error("🚨 **Poor**: PM2.5 level is high and may pose health risks")
                    
                    st.write("**This prediction is based on:**")
                    st.write(f"- 📍 Geographic location (Lat: {latitude:.2f}, Lon: {longitude:.2f})")
                    st.write(f"- 📅 Temporal factors (Year: {year}, Month: {month})")
                    st.write(f"- 🏙️ City characteristics: {city}, {country}")
                    
                except Exception as e:
                    st.error(f"Error making prediction: {str(e)}")
        
        with col2:
            st.subheader("Model Information")
            
            st.write("**Model Type:** Random Forest Regressor")
            st.write("**Target Variable:** PM2.5 concentration (μg/m³)")
            
            if hasattr(model_artifacts['model'], 'feature_importances_'):
                st.write("**Features Used:**")
                feature_importance = pd.DataFrame({
                    'Feature': model_artifacts['feature_columns'],
                    'Importance': model_artifacts['model'].feature_importances_
                }).sort_values('Importance', ascending=False)
                
                fig, ax = plt.subplots(figsize=(10, 8))
                sns.barplot(data=feature_importance.head(10), y='Feature', x='Importance', ax=ax)
                ax.set_title('Top 10 Feature Importances')
                ax.set_xlabel('Importance Score')
                plt.tight_layout()
                st.pyplot(fig)
            
            st.subheader("Model Performance")
            st.write("The model was evaluated using:")
            st.write("- **R² Score**: Measures how well the model explains variance")
            st.write("- **RMSE**: Root Mean Square Error (lower is better)")
            st.write("- **Cross-validation**: 5-fold CV for robust performance estimation")

else:  # About & Metadata
    st.header("📋 About & Metadata")
    
    if metadata:
        st.subheader("Dataset Information")
        st.write(f"**Dataset Name:** {metadata.get('dataset_name', 'Not specified')}")
        st.write(f"**Version:** {metadata.get('version', 'Not specified')}")
        st.write(f"**Creation Date:** {metadata.get('creation_date', 'Not specified')}")
        st.write(f"**Total Records:** {metadata.get('total_records', 'Not specified')}")
        st.write(f"**Geographic Coverage:** {metadata.get('geographic_coverage', 'Not specified')}")
        st.write(f"**Temporal Coverage:** {metadata.get('temporal_coverage', 'Not specified')}")
        
        st.subheader("Data Sources")
        sources = metadata.get('data_sources', {})
        if sources:
            for source, description in sources.items():
                st.write(f"**{source}:** {description}")
        else:
            st.write("No data sources specified")
        
        st.subheader("Data Quality Notes")
        notes = metadata.get('data_quality_notes', [])
        if notes:
            for note in notes:
                st.write(f"• {note}")
        else:
            st.write("No quality notes available")
        
        st.subheader("Usage Recommendations")
        recommendations = metadata.get('usage_recommendations', [])
        if recommendations:
            for recommendation in recommendations:
                st.write(f"• {recommendation}")
        else:
            st.write("No usage recommendations available")
        
        st.subheader("Citation")
        st.write(metadata.get('citation', 'Not specified'))
        
        st.subheader("License")
        st.write(metadata.get('license', 'Not specified'))
        
        st.subheader("Contact")
        st.write(metadata.get('contact', 'Not specified'))
    else:
        st.error("No metadata available")

# Footer
st.markdown("---")
st.markdown("Built with Streamlit | Urban Air Quality Analysis Dashboard")