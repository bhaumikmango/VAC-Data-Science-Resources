# Urban Air Quality Analysis & Prediction

An interactive streamlit web application for exploring global urban air quality data and predicting PM2.5 levels using machine learning.

## Dataset Details

- Filename: air_quality_global.csv
- Rows: 17,813 records
- Columns: city, country, latitude, longitude, year, month, pm25_ugm3, no2_ugm3, data_quality, measurement_method, data_source
- License: Creative Commons CC0 1.0 (Public Domain)
- Metadata: Complete documentation in 'metadata.json' 

### Dataset Specifications from Metadata
- Dataset Name: Urban Air Quality and Climate Dataset (1958-2025)
- Version: 1.0
- Creation Date: 2025-09-20
- Geographic Coverage: Global (20 major cities)
- Temporal Coverage: 2000 years (ice core) + 67 years (direct measurements)

## Objective & Tasks Implemented

Primary Modeling Task: Regression analysis to predict PM2.5 concentration levels based on geographic, temporal, and categorical features.

Implemented Tasks:
- Data Loading & Preprocessing: Handles missing or absent files gracefully with demo data fallback.

- Exploratory Data Analysis (EDA): Visual exploration via histograms, trends, and geo-maps.

- Model Training & Prediction: Machine learning model (Random Forest Regressor) trained to predict PM2.5 levels.

- Interactive Web Interface: Built using Streamlit with three sections:

I) Data Explorer (EDA)

II) Model Predictor (PM2.5 prediction)

III) About & Metadata (dataset information)

## How to Run

### Dependencies

pip install -r requirements.txt

### Commands 
# Run Jupyter notebook for EDA and model training
jupyter notebook notebooks/air.ipynb

# Launch Streamlit web application
streamlit run app/main.py

### Web App Access
Local URL: http://localhost:8501

### File structure 
urban_air_quality_analysis/
├── app/
│   └── main.py              # Main Streamlit application
├── notebooks/
│   └── air.ipynb        # Jupyter notebook for analysis
├── data/
│   ├── air_quality_global.csv        # Primary dataset
│   └── metadata.json                 # json file  documentation
├── models/
│   ├── air_quality_model.pkl         # Base trained model
│   └── air_quality_model_tuned.pkl   # Hyperparameter-tuned model
├── assets/                           # Screenshots and images
├── requirements.txt                  # Python dependencies
└── README.md                         # Project documentation

### EDA Summary: Three Key Findings

1. Geographic Pollution Hotspots: Delhi shows critically high PM2.5 levels (132.0 ), followed by Mumbai (99.3) and Beijing (75.3), indicating severe air quality challenges in major Asian and African metropolitan areas.

2. Seasonal Pollution Patterns: PM2.5 concentrations exhibit a clear seasonal cycle, peaking in spring months (April: 54.4) and reaching the lowest levels in autumn (September: 29.3), suggesting strong meteorological and seasonal influences on air quality.

3. Moderate Pollutant Correlation: A moderate positive correlation (r=0.49) exists between PM2.5 and NO2 levels, indicating these pollutants share some common emission sources but are also influenced by distinct atmospheric processes and source contributions.

### Model Details
### Algorithm
- Primary Modeling Task : Random Forest Regressor
- Baseline Comparison : Linear Regression

### Hyperparameters Tuned & Final Values
python
{
    'n_estimators': 200,      # Number of trees in forest
    'max_depth': 20,          # Maximum depth of trees
    'min_samples_split': 2,   # Minimum samples required to split
    'random_state': 42        # Reproducibility seed
}

### Evaluation Metrics
- R^2 Score: 0.82 (82% of variance explained)

- RMSE: 8.45 

- Cross-validation Score: 0.79 +- 0.04

### Design Decisions & Assumptions
### Missing Value Strategy
- Numerical features: Median imputation (robust to outliers)

- Categorical features: Mode imputation 

- Target variable: Row deletion (avoiding target leakage)

### Feature Engineering
- Categorical encoding: Label encoding for city, country, measurement methods

- Feature scaling: StandardScaler applied to all numerical features

- Temporal features: Year and month used as cyclical features

### Data Quality Handling
- Quality flags from metadata used to filter low-confidence measurements

- Geographic coordinates validated for reasonable ranges

- Extreme outliers (>3 sigma) handled appropiately

### Assumptions
- Measurements are representative of urban background concentrations

- Missing data is Missing At Random (MAR)

- Seasonal patterns are consistent across years

- Geographic features adequately capture local emission characteristics

### Screenshots
'C:\Documents\Desktop\air_quality\assets'

### Contact & Authorship
Name: Kunjum Mittal

Email: Kunjum7025@gmail.com

### How to reproduce results
# Step 1: Open the modeling notebook
jupyter notebook notebooks/air.ipynb

# Step 2: Run all cells to preprocess data, train the model, and save it
This generates: models/air_quality_model_tuned.pkl
This generates: models/air_quality_model.pkl

# Step 3: Launch the Streamlit app
streamlit run app.py
