"""
Tkinter Air Quality Quick-Dev App
Connects to repo-level data/, models/, assets/, notebooks/.
Features:
 - Load data & metadata from repo/data
 - Filters: country, city, year, month
 - EDA: histograms, time series, map scatter
 - Model view: load model, dynamic feature inputs for custom prediction,
   compute regression metrics (RMSE, R2) and show confusion matrix if classification target
 - Explainability: feature importance (for supported models)
 - About / Metadata page
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import pandas as pd
import json
import datetime as dt
import joblib
import numpy as np
import seaborn as sns
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score, confusion_matrix, accuracy_score

# ---- Repo root and canonical folders ----
def find_repo_root(start=Path(__file__).resolve(), markers=('app', 'data', 'README.md', '.git', 'notebooks')):
    p = start
    for parent in [p] + list(p.parents):
        for m in markers:
            if (parent / m).exists():
                return parent
    return start.parent

REPO_ROOT = find_repo_root()
DATA_DIR = REPO_ROOT / 'data'
MODELS_DIR = REPO_ROOT / 'models'
ASSETS_DIR = REPO_ROOT / 'assets'
NOTEBOOKS_DIR = REPO_ROOT / 'notebooks'

CSV_PATH = DATA_DIR / 'air_quality_global.csv'
META_PATH = DATA_DIR / 'metadata.json'
DEFAULT_SAMPLE_PATH = DATA_DIR / 'air_quality_sample.csv'
DEFAULT_MODEL_META = MODELS_DIR / 'random_forest_pm25_metadata.json'
DEFAULT_MODEL_FILE = MODELS_DIR / 'best_model_pm25.joblib'

# create data/models folders if missing (do NOT create assets; require existing)
DATA_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)

# ---- Utility / Data functions ----
def load_data(path=None):
    path = Path(path) if path is not None else CSV_PATH
    if not path.exists():
        raise FileNotFoundError(f"CSV not found at {path}. Place air_quality_global.csv or air_quality_sample.csv in {DATA_DIR}.")
    return pd.read_csv(path)

def load_metadata(path=None):
    path = Path(path) if path is not None else META_PATH
    if not path.exists():
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def try_parse_datetime_column(df):
    candidates = ['date', 'timestamp', 'datetime', 'time'] + [c for c in df.columns if 'date' in c.lower() or 'time' in c.lower()]
    for c in candidates:
        if c in df.columns:
            try:
                parsed = pd.to_datetime(df[c], errors='coerce')
                if parsed.notnull().sum() > 0:
                    df[c] = parsed
                    return c
            except Exception:
                continue
    return None

def clean_basic(df):
    df = df.copy()
    df.columns = [str(col).strip() for col in df.columns]
    df.replace(['NA','N/A','na','n/a','None','none',''], pd.NA, inplace=True)
    for col in df.select_dtypes(include=[np.number]).columns:
        df.loc[df[col]==-999, col] = pd.NA
        df.loc[df[col]==-9999, col] = pd.NA
    df.dropna(axis=1, how='all', inplace=True)
    df.dropna(axis=0, how='all', inplace=True)
    return df

# ---- Model helpers ----
def load_model_metadata(path=None):
    path = Path(path) if path is not None else DEFAULT_MODEL_META
    if not path.exists():
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return None

def load_model(path=None):
    if path is not None:
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Specified model file not found: {p}")
        try:
            return joblib.load(p)
        except Exception as e:
            raise RuntimeError(f"Failed to load model at {p}: {e}")

    p = DEFAULT_MODEL_FILE
    if not p.exists():
        raise FileNotFoundError(f"Model file not found at {p}. Place 'best_model_pm25.joblib' in {MODELS_DIR}.")
    try:
        return joblib.load(p)
    except Exception as e:
        raise RuntimeError(f"Failed to load model at {p}: {e}")

# ---- Tkinter Application ----
class AirQualityApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Air Quality — Quick Dev UI')
        self.geometry('1100x700')
        self.minsize(800, 500)

        self.df = None
        self.filtered_df = None
        self.metadata = None
        self.datetime_col = None
        self.model = None
        self.model_meta = None
        self.model_target = 'pm25_ugm3'

        # model target combobox (kept in app but not shown in controls frame)
        self.model_target_cb = ttk.Combobox(self, values=[], state='readonly')

        self.create_widgets()

    def create_widgets(self):
        paned = ttk.Panedwindow(self, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True)

        left_container = ttk.Frame(paned, width=320)
        right_container = ttk.Frame(paned)

        paned.add(left_container, weight=1)
        paned.add(right_container, weight=4)

        canvas = tk.Canvas(left_container, borderwidth=0, highlightthickness=0)
        vscroll = ttk.Scrollbar(left_container, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=vscroll.set)
        vscroll.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        controls_frame = ttk.Frame(canvas)
        canvas.create_window((0, 0), window=controls_frame, anchor='nw')
        controls_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        ttk.Label(controls_frame, text='Data Controls', font=('Segoe UI', 11, 'bold')).pack(anchor='w', pady=(6, 4), padx=6)
        ttk.Button(controls_frame, text='Load Data', command=self.on_load_data).pack(fill=tk.X, padx=6)
        ttk.Button(controls_frame, text='Load Metadata', command=self.on_load_metadata).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Show Data Info', command=self.on_show_info).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Show Head (10 rows)', command=self.on_show_head).pack(fill=tk.X, pady=(6, 0), padx=6)

        ttk.Separator(controls_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=8, padx=6)

        ttk.Label(controls_frame, text='Filters', font=('Segoe UI', 11, 'bold')).pack(anchor='w', padx=6)
        ttk.Label(controls_frame, text='Country:').pack(anchor='w', padx=6)
        self.country_cb = ttk.Combobox(controls_frame, values=[], state='readonly')
        self.country_cb.pack(fill=tk.X, padx=6)
        ttk.Label(controls_frame, text='City:').pack(anchor='w', padx=6, pady=(6, 0))
        self.city_cb = ttk.Combobox(controls_frame, values=[], state='readonly')
        self.city_cb.pack(fill=tk.X, padx=6)
        ttk.Label(controls_frame, text='Year:').pack(anchor='w', padx=6, pady=(6, 0))
        self.year_cb = ttk.Combobox(controls_frame, values=[], state='readonly')
        self.year_cb.pack(fill=tk.X, padx=6)
        ttk.Label(controls_frame, text='Month:').pack(anchor='w', padx=6, pady=(6, 0))
        self.month_cb = ttk.Combobox(controls_frame, values=['All'] + list(range(1, 13)), state='readonly')
        self.month_cb.pack(fill=tk.X, padx=6)
        ttk.Button(controls_frame, text='Apply Filters', command=self.apply_filters).pack(fill=tk.X, pady=(8, 0), padx=6)
        ttk.Button(controls_frame, text='Reset Filters', command=self.reset_filters).pack(fill=tk.X, pady=(6, 0), padx=6)

        ttk.Separator(controls_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=8, padx=6)
        ttk.Label(controls_frame, text='EDA', font=('Segoe UI', 11, 'bold')).pack(anchor='w', padx=6)
        ttk.Label(controls_frame, text='Numeric column:').pack(anchor='w', padx=6, pady=(6, 0))
        self.num_col_cb = ttk.Combobox(controls_frame, values=[], state='readonly')
        self.num_col_cb.pack(fill=tk.X, padx=6)
        ttk.Button(controls_frame, text='Plot Distribution', command=self.on_plot_hist).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Plot Map (lat/lon)', command=self.on_plot_map).pack(fill=tk.X, pady=(6, 0), padx=6)

        ttk.Separator(controls_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=8, padx=6)
        ttk.Label(controls_frame, text='Time Series', font=('Segoe UI', 11, 'bold')).pack(anchor='w', padx=6)
        ttk.Label(controls_frame, text='Datetime column:').pack(anchor='w', pady=(6, 0), padx=6)
        self.dt_col_cb = ttk.Combobox(controls_frame, values=[], state='readonly')
        self.dt_col_cb.pack(fill=tk.X, padx=6)
        ttk.Label(controls_frame, text='Value column:').pack(anchor='w', pady=(6, 0), padx=6)
        self.ts_col_cb = ttk.Combobox(controls_frame, values=[], state='readonly')
        self.ts_col_cb.pack(fill=tk.X, padx=6)
        ttk.Button(controls_frame, text='Plot Time Series (daily mean)', command=self.on_plot_ts).pack(fill=tk.X, pady=(6, 0), padx=6)

        ttk.Separator(controls_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=8, padx=6)
        ttk.Label(controls_frame, text='Model', font=('Segoe UI', 11, 'bold')).pack(anchor='w', padx=6)
        ttk.Button(controls_frame, text='Load Model', command=self.on_load_model).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Show Model Info', command=self.on_show_model_info).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Open Predictor Window', command=self.open_predictor_window).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Compute Eval Metrics (on current filter)', command=self.on_compute_metrics).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Show Feature Importance', command=self.on_show_feature_importance).pack(fill=tk.X, pady=(6, 0), padx=6)

        ttk.Separator(controls_frame, orient=tk.HORIZONTAL).pack(fill=tk.X, pady=8, padx=6)
        ttk.Button(controls_frame, text='About / Metadata', command=self.on_show_about).pack(fill=tk.X, padx=6)
        ttk.Button(controls_frame, text='Export Cleaned CSV', command=self.on_export_cleaned).pack(fill=tk.X, pady=(6, 0), padx=6)
        ttk.Button(controls_frame, text='Choose Different CSV...', command=self.on_choose_csv).pack(fill=tk.X, pady=(6, 6), padx=6)

        out = right_container
        out.pack_propagate(False)

        self.info_text = tk.Text(out, height=7)
        self.info_text.pack(side=tk.TOP, fill=tk.X)

        self.fig = plt.Figure(figsize=(8, 6), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=out)
        self.canvas_widget = self.canvas.get_tk_widget()
        self.canvas_widget.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

    # ---- Data actions ----
    def on_load_data(self):
        try:
            # prefer sample if present
            path = DEFAULT_SAMPLE_PATH if DEFAULT_SAMPLE_PATH.exists() else CSV_PATH
            self.df = load_data(path)
            self.df = clean_basic(self.df)
            self.metadata = load_metadata()
            self.datetime_col = try_parse_datetime_column(self.df)
            self.filtered_df = self.df.copy()
            self.update_column_selectors()
            self.populate_filter_values()
            self.populate_model_target_options()
            if self.datetime_col and self.dt_col_cb['values'] and self.datetime_col in self.dt_col_cb['values']:
                self.dt_col_cb.set(self.datetime_col)
            self.log(f"Loaded data: {path} — {len(self.df)} rows, {len(self.df.columns)} cols")
        except Exception as e:
            messagebox.showerror('Error loading data', str(e))

    def on_load_metadata(self):
        m = load_metadata()
        if m is None:
            messagebox.showinfo('Metadata', 'No metadata.json found or it could not be parsed.')
        else:
            self.metadata = m
            self.show_text_popup('Dataset Metadata', json.dumps(m, indent=2))

    def on_show_info(self):
        if self.df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        buf = []
        buf.append(f"Shape: {self.df.shape}")
        buf.append('\nColumns and dtypes:\n')
        buf.append(str(self.df.dtypes))
        buf.append('\n\nNull counts:\n')
        buf.append(str(self.df.isnull().sum().sort_values(ascending=False).head(50)))
        self.show_text_popup('Data Info', '\n'.join(buf))

    def on_show_head(self):
        if self.filtered_df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        self.show_text_popup('Head (10 rows)', self.filtered_df.head(10).to_string())

    def populate_filter_values(self):
        if self.df is None:
            return
        if 'country' in self.df.columns:
            vals = ['All'] + sorted(self.df['country'].dropna().unique().astype(str).tolist())
            self.country_cb['values'] = vals
            self.country_cb.set('All')
        if 'city' in self.df.columns:
            vals = ['All'] + sorted(self.df['city'].dropna().unique().astype(str).tolist())
            self.city_cb['values'] = vals
            self.city_cb.set('All')
        years = ['All']
        if self.datetime_col:
            try:
                years += sorted(self.df[self.datetime_col].dt.year.dropna().unique().tolist())
            except Exception:
                pass
        else:
            for c in self.df.columns:
                if 'year' in c.lower():
                    years += sorted(self.df[c].dropna().unique().tolist())
                    break
        self.year_cb['values'] = years
        if years:
            self.year_cb.set(years[0])
        self.month_cb.set('All')

    def apply_filters(self):
        if self.df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        df = self.df.copy()
        c = self.country_cb.get() if hasattr(self, 'country_cb') else 'All'
        ci = self.city_cb.get() if hasattr(self, 'city_cb') else 'All'
        yr = self.year_cb.get() if hasattr(self, 'year_cb') else 'All'
        mo = self.month_cb.get() if hasattr(self, 'month_cb') else 'All'

        if c and c != 'All' and 'country' in df.columns:
            df = df[df['country'].astype(str) == str(c)]
        if ci and ci != 'All' and 'city' in df.columns:
            df = df[df['city'].astype(str) == str(ci)]
        if yr and yr != 'All' and self.datetime_col:
            try:
                df = df[df[self.datetime_col].dt.year == int(yr)]
            except Exception:
                pass
        if mo and mo != 'All' and self.datetime_col:
            try:
                df = df[df[self.datetime_col].dt.month == int(mo)]
            except Exception:
                pass

        self.filtered_df = df
        self.log(f'Applied filters -> {len(df)} rows remain')
        self.update_column_selectors()

    def reset_filters(self):
        if self.df is None:
            return
        self.filtered_df = self.df.copy()
        self.populate_filter_values()
        self.log('Filters reset')

    # ---- Plotting / EDA ----
    def on_plot_hist(self):
        if self.filtered_df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        col = self.num_col_cb.get()
        if not col:
            messagebox.showwarning('Choose column', 'Choose a numeric column to plot.')
            return
        self.ax.clear()
        try:
            series = pd.to_numeric(self.filtered_df[col], errors='coerce').dropna()
            self.ax.hist(series, bins=30, color='#3366cc', edgecolor='black')
            self.ax.set_title(f'Distribution: {col} (n={len(series)})')
            self.ax.set_xlabel(col)
            self.ax.set_ylabel('Count')
            self.canvas.draw()
        except Exception as e:
            messagebox.showerror('Plot error', str(e))

    def on_plot_map(self):
        if self.filtered_df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        if 'latitude' not in self.filtered_df.columns or 'longitude' not in self.filtered_df.columns:
            messagebox.showwarning('No coordinates', 'Dataset lacks latitude/longitude columns.')
            return
        valcol = self.num_col_cb.get() or self.model_target
        df_map = self.filtered_df.copy()
        if valcol in df_map.columns:
            df_map = df_map.dropna(subset=['latitude', 'longitude', valcol])
            cvals = pd.to_numeric(df_map[valcol], errors='coerce')
        else:
            df_map = df_map.dropna(subset=['latitude', 'longitude'])
            cvals = None
        if df_map.empty:
            messagebox.showwarning('No data', 'No rows with lat/lon (and chosen value).')
            return
        self.ax.clear()
        if cvals is not None and not cvals.empty:
            sc = self.ax.scatter(df_map['longitude'].astype(float), df_map['latitude'].astype(float),
                                 c=cvals, cmap='viridis', s=20, alpha=0.8)
            try:
                self.fig.colorbar(sc, ax=self.ax, label=valcol)
            except Exception:
                pass
        else:
            self.ax.scatter(df_map['longitude'].astype(float), df_map['latitude'].astype(float),
                            color='#1f77b4', s=20, alpha=0.8)
        self.ax.set_title(f'Map scatter ({valcol})')
        self.ax.set_xlabel('Longitude')
        self.ax.set_ylabel('Latitude')
        self.canvas.draw()

    def on_plot_ts(self):
        if self.filtered_df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        ts_col = self.dt_col_cb.get() if self.dt_col_cb.get() else self.datetime_col
        val_col = self.ts_col_cb.get()
        if not ts_col:
            messagebox.showwarning('No datetime', 'No datetime-like column detected. Choose one.')
            return
        if not val_col:
            messagebox.showwarning('Choose column', 'Choose a numeric column to aggregate in time series.')
            return
        try:
            tmp = self.filtered_df[[ts_col, val_col]].copy()
            tmp[ts_col] = pd.to_datetime(tmp[ts_col], errors='coerce')
            tmp[val_col] = pd.to_numeric(tmp[val_col], errors='coerce')
            tmp = tmp.dropna(subset=[ts_col, val_col])
            if tmp.empty:
                messagebox.showwarning('No data', 'No valid rows after parsing datetime and numeric values.')
                return
            tmp.set_index(ts_col, inplace=True)
            tmp.sort_index(inplace=True)
            daily = tmp.resample('D').mean()
            if daily.empty:
                messagebox.showwarning('No data', 'Resampled time series is empty.')
                return
            self.ax.clear()
            self.ax.plot(daily.index, daily[val_col], color='#cc3333')
            self.ax.set_title(f'{val_col} — daily mean (filtered)')
            self.ax.set_ylabel(val_col)
            self.ax.set_xlabel('Date')
            self.canvas.draw()
        except Exception as e:
            messagebox.showerror('Plot error', str(e))

    def on_export_cleaned(self):
        if self.filtered_df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        suggested = DATA_DIR / f'cleaned_{CSV_PATH.stem}.csv'
        out_path = filedialog.asksaveasfilename(defaultextension='.csv', initialfile=suggested.name, initialdir=str(DATA_DIR))
        if not out_path:
            return
        try:
            self.filtered_df.to_csv(out_path, index=False)
            messagebox.showinfo('Saved', f'Cleaned dataset saved to {out_path}')
        except Exception as e:
            messagebox.showerror('Save error', str(e))

    def on_choose_csv(self):
        path = filedialog.askopenfilename(filetypes=[('CSV files', '*.csv')], initialdir=str(REPO_ROOT))
        if not path:
            return
        try:
            p = Path(path)
            df_new = pd.read_csv(p)
            self.df = clean_basic(df_new)
            self.datetime_col = try_parse_datetime_column(self.df)
            self.filtered_df = self.df.copy()
            self.update_column_selectors()
            self.populate_filter_values()
            self.populate_model_target_options()
            if self.datetime_col and hasattr(self, 'dt_col_cb') and self.datetime_col in self.dt_col_cb['values']:
                self.dt_col_cb.set(self.datetime_col)
            self.log(f'Loaded selected CSV: {p} — {len(self.df)} rows')
        except Exception as e:
            messagebox.showerror('Load error', str(e))

    # ---- Model actions ----
    def on_load_model(self):
        try:
            self.model_meta = load_model_metadata()
            self.model = load_model()
            if isinstance(self.model_meta, dict) and 'target' in self.model_meta:
                self.model_target = self.model_meta['target']
            self.populate_model_target_options()
            self.log(f"Loaded model file: {DEFAULT_MODEL_FILE}")
            messagebox.showinfo('Model loaded', f"Model loaded from {DEFAULT_MODEL_FILE}")
        except Exception as e:
            messagebox.showerror('Model load error', str(e))

    def on_show_model_info(self):
        if self.model is None and self.model_meta is None:
            messagebox.showinfo('Model info', 'No model loaded. Use Load Model.')
            return
        info = {}
        if self.model_meta:
            info.update(self.model_meta)
        info['model_object'] = type(self.model).__name__ if self.model is not None else None
        info['app_model_target'] = self.model_target
        self.show_text_popup('Model Info', json.dumps(info, indent=2))

    def populate_model_target_options(self):
        if self.df is None:
            return
        numeric = [c for c in self.df.columns if pd.api.types.is_numeric_dtype(self.df[c])]
        vals = numeric + [c for c in self.df.columns if c not in numeric]
        self.model_target_cb['values'] = vals
        if self.model_target in vals:
            self.model_target_cb.set(self.model_target)
        elif vals:
            self.model_target_cb.set(vals[0])

    def on_compute_metrics(self):
        if self.model is None:
            messagebox.showwarning('No model', 'Load model first.')
            return
        if self.filtered_df is None:
            messagebox.showwarning('No data', 'Load data first.')
            return
        if isinstance(self.model_meta, dict) and 'features' in self.model_meta:
            feat_cols = list(self.model_meta['features'])
        else:
            feat_cols = [c for c in self.filtered_df.columns if pd.api.types.is_numeric_dtype(self.filtered_df[c]) and c != self.model_target]
            if not feat_cols:
                messagebox.showwarning('No features', 'Could not infer feature columns for the model.')
                return

        missing = [c for c in feat_cols if c not in self.filtered_df.columns]
        if missing:
            if messagebox.askyesno('Missing features', f'Missing features: {missing}\nFill with zeros and continue?'):
                for c in missing:
                    self.filtered_df[c] = 0.0
            else:
                return

        X = self.filtered_df[feat_cols].apply(pd.to_numeric, errors='coerce')
        y = None
        if self.model_target in self.filtered_df.columns:
            y = pd.to_numeric(self.filtered_df[self.model_target], errors='coerce')
            valid_idx = X.dropna(how='all').index.intersection(y.dropna().index)
        else:
            valid_idx = X.dropna(how='all').index

        if len(valid_idx) == 0:
            messagebox.showwarning('No valid rows', 'No valid rows to compute metrics.')
            return

        X_eval = X.loc[valid_idx].fillna(X.median())
        try:
            preds = self.model.predict(X_eval)
        except Exception as e:
            messagebox.showerror('Prediction error', f'Failed to run model.predict: {e}')
            return

        metrics = {}
        if y is not None:
            y_eval = y.loc[valid_idx]
            if y_eval.nunique() <= 20 and (y_eval.dropna().apply(float).round().equals(y_eval.dropna())):
                try:
                    cm = confusion_matrix(y_eval, np.round(preds).astype(int))
                    acc = accuracy_score(y_eval, np.round(preds).astype(int))
                    metrics['accuracy'] = float(acc)
                    metrics['confusion_matrix'] = cm.tolist()
                except Exception:
                    metrics['rmse'] = float(mean_squared_error(y_eval, preds, squared=False))
                    metrics['r2'] = float(r2_score(y_eval, preds))
            else:
                metrics['rmse'] = float(mean_squared_error(y_eval, preds, squared=False))
                metrics['r2'] = float(r2_score(y_eval, preds))
        else:
            metrics['note'] = 'No target column available in filtered data to compute supervised metrics.'

        self.show_text_popup('Model evaluation metrics', json.dumps(metrics, indent=2))
        if 'confusion_matrix' in metrics:
            cm = np.array(metrics['confusion_matrix'])
            fig, ax = plt.subplots(figsize=(4, 4))
            sns.heatmap(cm, annot=True, fmt='g', ax=ax, cmap='Blues')
            ax.set_title('Confusion Matrix')
            self._show_figure_popup(fig, title='Confusion Matrix')
            plt.close(fig)

    def open_predictor_window(self):
        if self.model is None:
            messagebox.showwarning('No model', 'Load model first.')
            return
        if isinstance(self.model_meta, dict) and 'features' in self.model_meta:
            feat_cols = list(self.model_meta['features'])
        else:
            if self.filtered_df is None:
                messagebox.showwarning('No data', 'Load data first.')
                return
            feat_cols = [c for c in self.filtered_df.columns if pd.api.types.is_numeric_dtype(self.filtered_df[c]) and c != self.model_target]
        if not feat_cols:
            messagebox.showwarning('No features', 'No feature columns available for prediction.')
            return

        win = tk.Toplevel(self)
        win.title('Custom Predictor')
        frm = ttk.Frame(win)
        frm.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        entries = {}
        ttk.Label(frm, text='Enter feature values (leave blank for median):', font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        canvas = tk.Canvas(frm)
        sc = ttk.Scrollbar(frm, orient='vertical', command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner_id = canvas.create_window((0, 0), window=inner, anchor='nw')
        canvas.configure(yscrollcommand=sc.set)
        sc.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

        medians = {}
        if self.filtered_df is not None:
            medians = self.filtered_df[feat_cols].apply(pd.to_numeric, errors='coerce').median().to_dict()

        for f in feat_cols:
            row = ttk.Frame(inner)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text=f, width=30).pack(side=tk.LEFT)
            ent = ttk.Entry(row)
            ent.pack(side=tk.LEFT, fill=tk.X, expand=True)
            if f in medians and not np.isnan(medians[f]):
                ent.insert(0, str(medians[f]))
            entries[f] = ent

        def do_predict():
            vals = {}
            for k, e in entries.items():
                txt = e.get().strip()
                if txt == '':
                    vals[k] = medians.get(k, 0.0)
                else:
                    try:
                        vals[k] = float(txt)
                    except Exception:
                        messagebox.showerror('Input error', f'Invalid numeric input for {k}: {txt}')
                        return
            X = pd.DataFrame([vals])
            try:
                pred = self.model.predict(X)[0]
            except Exception as e:
                messagebox.showerror('Prediction error', f'Failed to run model.predict: {e}')
                return
            messagebox.showinfo('Prediction result', f'Predicted {self.model_target}: {pred}')

        btn = ttk.Button(win, text='Predict', command=do_predict)
        btn.pack(pady=6)

    # ---- Step 7 — Feature Importance ----
    def on_show_feature_importance(self):
        if self.model is None:
            messagebox.showwarning('No model', 'Load model first.')
            return
        if hasattr(self.model, 'feature_importances_'):
            feats = None
            if self.model_meta and 'features' in self.model_meta:
                feats = self.model_meta['features']
            else:
                feats = [f"f{i}" for i in range(len(self.model.feature_importances_))]

            imp = pd.Series(self.model.feature_importances_, index=feats).sort_values(ascending=False)
            fig, ax = plt.subplots(figsize=(6, 4))
            imp.plot(kind='bar', ax=ax, color='#4c72b0')
            ax.set_title('Feature Importances')
            ax.set_xlabel('Features')
            ax.set_ylabel('Importance')
            fig.tight_layout()
            self._show_figure_popup(fig, 'Feature Importance')
            plt.close(fig)
        else:
            messagebox.showinfo('Not available', 'This model does not provide feature_importances_ attribute.')

    # ---- Helpers ----
    def update_column_selectors(self):
        if self.filtered_df is None:
            return
        numeric_cols = [c for c in self.filtered_df.columns if pd.api.types.is_numeric_dtype(self.filtered_df[c])]
        if not numeric_cols:
            for c in self.filtered_df.columns:
                try:
                    pd.to_numeric(self.filtered_df[c].dropna().iloc[:50])
                    numeric_cols.append(c)
                except Exception:
                    pass

        date_like = []
        for c in self.filtered_df.columns:
            try:
                parsed = pd.to_datetime(self.filtered_df[c], errors='coerce')
                if parsed.notna().any():
                    date_like.append(c)
            except Exception:
                continue

        self.num_col_cb['values'] = numeric_cols
        if numeric_cols and not self.num_col_cb.get():
            self.num_col_cb.set(numeric_cols[0])

        dt_vals = date_like if date_like else list(self.filtered_df.columns)
        self.dt_col_cb['values'] = dt_vals
        if self.datetime_col and self.datetime_col in dt_vals:
            self.dt_col_cb.set(self.datetime_col)
        elif dt_vals and not self.dt_col_cb.get():
            self.dt_col_cb.set(dt_vals[0])

        self.ts_col_cb['values'] = numeric_cols
        if numeric_cols and not self.ts_col_cb.get():
            self.ts_col_cb.set(numeric_cols[0])

        try:
            vals = list(self.filtered_df.columns)
            self.model_target_cb['values'] = vals
        except Exception:
            pass

    def log(self, msg):
        timestamp = dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.info_text.insert('end', f'[{timestamp}] {msg}\n')
        self.info_text.see('end')

    def show_text_popup(self, title, text):
        win = tk.Toplevel(self)
        win.title(title)
        txt = tk.Text(win, wrap='none')
        txt.insert('1.0', text)
        txt.pack(expand=True, fill='both')
        btn = ttk.Button(win, text='Close', command=win.destroy)
        btn.pack()

    def _show_figure_popup(self, fig, title='Figure'):
        win = tk.Toplevel(self)
        win.title(title)
        canvas = FigureCanvasTkAgg(fig, master=win)
        cw = canvas.get_tk_widget()
        cw.pack(fill=tk.BOTH, expand=True)
        canvas.draw()
        btn = ttk.Button(win, text='Close', command=win.destroy)
        btn.pack()

    def on_show_about(self):
        info = {'app': 'Air Quality Quick Dev UI', 'repo_root': str(REPO_ROOT)}
        if self.metadata:
            info['dataset_metadata'] = self.metadata
        if self.model_meta:
            info['model_metadata'] = self.model_meta
        # include available assets/notebooks list
        try:
            info['assets_exist'] = ASSETS_DIR.exists()
            if NOTEBOOKS_DIR.exists():
                info['notebooks'] = [p.name for p in NOTEBOOKS_DIR.glob('*.ipynb')]
        except Exception:
            pass
        self.show_text_popup('About / Metadata', json.dumps(info, indent=2))


# ---- Run the app ----
if __name__ == '__main__':
    app = AirQualityApp()
    app.mainloop()