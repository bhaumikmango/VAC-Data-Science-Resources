# Air Quality PM2.5 Predictor

**Description:** A simple Tkinter app that predicts PM2.5 levels based on latitude, longitude, year, month, and NO2.

**Dataset:** `Air.csv` with `metadata.json`, Public domain (CC0).

**How to Run:** Install dependencies with `pip install pandas scikit-learn joblib`, then run the app by navigating to the app folder `cd app` and executing `python app.py`. Enter input values and click **Predict PM2.5**.

**Sample Inputs:** | Latitude | Longitude | Year | Month | NO2 (µg/m³) | |----------|-----------|------|-------|--------------| | 28.6139  | 77.2090   | 2020 | 1     | 35 | | 19.0760  | 72.8777   | 2018 | 7     | 50 | | 13.0827  | 80.2707   | 2022 | 12    | 25 |

**Model:** Algorithm: Random Forest Regressor. Features: latitude, longitude, year, month, NO2. Saved files: `pm25_model.pkl`, `columns.pkl`.

**Folder Structure:** `app/` Tkinter code, `models/` saved model & columns, `data/` dataset, `notebooks/` AirQuality,  `README.md`, `requirements.txt`.

