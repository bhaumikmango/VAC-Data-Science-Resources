# ...existing code...
import tkinter as tk
from tkinter import messagebox, ttk
import pandas as pd
import joblib
import os
import sys

# --- Paths relative to this script ---
script_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(script_dir, '..', 'models', 'pm25_model.pkl')
columns_path = os.path.join(script_dir, '..', 'models', 'columns.pkl')

# --- Load model and columns (fail gracefully) ---
if not os.path.exists(model_path):
    print(f"Model not found: {model_path}", file=sys.stderr)
    tmp = tk.Tk(); tmp.withdraw(); messagebox.showerror("Error", f"Model not found:\n{model_path}"); tmp.destroy()
    sys.exit(1)

try:
    model_obj = joblib.load(model_path)
except Exception as e:
    print(f"Failed to load model: {e}", file=sys.stderr)
    tmp = tk.Tk(); tmp.withdraw(); messagebox.showerror("Error", f"Failed to load model:\n{e}"); tmp.destroy()
    sys.exit(1)

# unwrap if saved as dict
model = model_obj['model'] if isinstance(model_obj, dict) and 'model' in model_obj else model_obj

# Try to discover expected feature names (robust)
expected_columns = None

# 1) explicit columns file
if os.path.exists(columns_path):
    try:
        cols = joblib.load(columns_path)
        if isinstance(cols, (list, tuple, pd.Index)):
            expected_columns = list(cols)
    except Exception:
        expected_columns = None

# 2) columns inside saved dict artifact
if expected_columns is None and isinstance(model_obj, dict):
    expected_columns = model_obj.get('columns') or model_obj.get('feature_names')

# 3) sklearn attribute feature_names_in_
if expected_columns is None:
    try:
        if hasattr(model, "feature_names_in_"):
            expected_columns = list(getattr(model, "feature_names_in_"))
    except Exception:
        expected_columns = None

# 4) get_feature_names_out (transformers/pipelines)
if expected_columns is None:
    try:
        if hasattr(model, "get_feature_names_out"):
            out = model.get_feature_names_out()
            if isinstance(out, (list, tuple, pd.Index)):
                expected_columns = list(out)
    except Exception:
        expected_columns = None

# 5) fallback to minimal set (keeps GUI simple)
if expected_columns is None:
    expected_columns = ['latitude', 'longitude', 'year', 'month', 'no2_ugm3']

# normalize to strings
expected_columns = [str(c) for c in expected_columns]

# detect city one-hot columns (prefix city_ or similar)
city_prefixes = [c for c in expected_columns if c.lower().startswith('city_')]
city_options = [c.split('_', 1)[1] for c in city_prefixes] if city_prefixes else []

# --- Tkinter GUI ---
root = tk.Tk()
root.title("Air Quality PM2.5 Predictor")
root.geometry("520x360")

frame = tk.LabelFrame(root, text="Enter Input Features", padx=10, pady=10)
frame.pack(padx=10, pady=10, fill="x")

# Numeric inputs (keep 5 simple fields)
labels = ["Latitude", "Longitude", "Year", "Month", "NO2 (µg/m³)"]
entries = []

# sensible defaults
defaults = ["0.0", "0.0", "2023", "1", "0.0"]

for i, label in enumerate(labels):
    tk.Label(frame, text=f"{label}:").grid(row=i, column=0, sticky="w", pady=6)
    entry = tk.Entry(frame)
    entry.insert(0, defaults[i])
    entry.grid(row=i, column=1, pady=6)
    entries.append(entry)

# optional city dropdown if model expects city one-hot columns
city_var = None
if city_options:
    tk.Label(frame, text="City:").grid(row=len(labels), column=0, sticky="w", pady=6)
    city_var = tk.StringVar()
    city_cb = ttk.Combobox(frame, textvariable=city_var, values=city_options, state='readonly', width=18)
    city_cb.set(city_options[0])
    city_cb.grid(row=len(labels), column=1, pady=6)

def _parse_number(value: str, name: str, as_int: bool = False):
    s = str(value).strip()
    if s == "":
        raise ValueError(f"{name} is empty")
    s = s.replace(",", "")
    try:
        if as_int:
            return int(float(s))
        return float(s)
    except Exception:
        raise ValueError(f"Invalid value for {name}: '{value}'")

def predict_pm25():
    try:
        lat = _parse_number(entries[0].get(), "Latitude", as_int=False)
        lon = _parse_number(entries[1].get(), "Longitude", as_int=False)
        year_val = _parse_number(entries[2].get(), "Year", as_int=True)
        month_val = _parse_number(entries[3].get(), "Month", as_int=True)
        no2_val = _parse_number(entries[4].get(), "NO2 (µg/m³)", as_int=False)

        # prepare single-row dataframe with all expected columns (fill zeros)
        test_df = pd.DataFrame(columns=expected_columns)
        test_df.loc[0] = 0

        # set numeric fields by case-insensitive match
        mapping = {
            'latitude': lat,
            'longitude': lon,
            'year': year_val,
            'month': month_val,
            'no2_ugm3': no2_val
        }
        for target_name, val in mapping.items():
            for col in test_df.columns:
                if col.lower() == target_name:
                    test_df.at[0, col] = val
                    break

        # set city one-hot if provided
        if city_var and city_var.get():
            chosen = city_var.get()
            # try to find exact matching city column
            target_col = None
            for c in test_df.columns:
                low = c.lower()
                if low.startswith('city_') and low.endswith(chosen.lower()):
                    target_col = c
                    break
            # fall back: match by suffix ignoring case
            if target_col is None:
                for c in test_df.columns:
                    if c.lower().startswith('city_') and c.split('_',1)[1].lower() == chosen.lower():
                        target_col = c
                        break
            if target_col:
                test_df.at[0, target_col] = 1

        # ensure numeric columns are numeric where possible
        for c in test_df.columns:
            try:
                test_df[c] = pd.to_numeric(test_df[c], errors='ignore')
            except Exception:
                pass

        # get real estimator if artifact was dict-like
        mdl = model
        if isinstance(mdl, dict) and 'model' in mdl:
            mdl = mdl['model']

        # predict
        pred = mdl.predict(test_df)
        out = float(pred[0]) if hasattr(pred, '__len__') else float(pred)
        messagebox.showinfo("Prediction", f"Predicted PM2.5: {out:.2f} µg/m³")

    except ValueError as ve:
        messagebox.showerror("Input Error", str(ve))
    except Exception as e:
        # show underlying error (keeps message short)
        messagebox.showerror("Error", f"{e}")

tk.Button(frame, text="Predict PM2.5", command=predict_pm25, bg="lightblue").grid(row=6, column=0, columnspan=2, pady=15)

root.mainloop()
# ...existing code...