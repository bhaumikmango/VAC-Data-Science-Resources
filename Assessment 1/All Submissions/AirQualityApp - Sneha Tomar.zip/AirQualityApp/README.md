# 🌍 Urban Air Quality Analysis & Prediction (Tkinter)

An interactive **Tkinter desktop application** for exploring global urban air quality data and predicting PM2.5 concentrations using machine learning.

## 📊 Dataset Details

- **Filename:** `data/air_quality_global.csv`
- **Rows:** ~17,800 records
- **Columns:** 
  - Geographic: `city`, `country`, `latitude`, `longitude`
  - Temporal: `year`, `month`
  - Measurements: `pm25_ugm3`, `no2_ugm3`
  - Metadata: `data_quality`, `measurement_method`, `data_source`
- **License:** Creative Commons CC0 1.0 (Public Domain)
- **Documentation:** Complete metadata in `data/metadata.json`

### Dataset Specifications
- **Name:** Urban Air Quality and Climate Dataset (1958-2025)
- **Version:** 1.0
- **Creation:** 2025-09-20
- **Coverage:** Global (20 major cities)
- **Time Range:** 2000 years (ice core) + 67 years (direct measurements)

## 🎯 Objectives & Implementation

**Primary Task:** Regression analysis to predict PM2.5 concentration levels using geographic, temporal, and environmental features.

### Implemented Features
1. **Data Loading & Preprocessing:**
   - Graceful handling of missing/absent files
   - Sample dataset fallback (`air_quality_sample.csv`)
   - Automated feature engineering (month cyclical encoding)

2. **Interactive EDA:**
   - PM2.5 distribution histogram
   - Time series visualization by city
   - Geographic scatter plot (lat/lon)

3. **Model Integration:**
   - Trained RandomForestRegressor (log-target tuned)
   - Real-time predictions
   - Feature importance visualization

4. **User Interface:**
   - **Data Controls:** Load, filter, and inspect data
   - **EDA Tab:** Interactive visualizations
   - **Model Tab:** Load model, predict, explain
   - **About:** Dataset & model metadata viewer

---

## 📈 Key Findings

### EDA Summary
1. **Distribution:** PM2.5 shows right-skewed distribution with extended tail
2. **Correlations:** Positive relationship between PM2.5 and NO2 levels
3. **Seasonality:** Clear seasonal patterns detected in several major cities

### Model Performance
- **Algorithm:** RandomForestRegressor (log-target transformed)
- **Test RMSE:** 9.41 µg/m³
- **R² Score:** 0.292 (29.2% variance explained)
- **Features Used:**
  - NO2 concentration
  - Geographic coordinates (lat/lon)
  - Country indicator (USA)
  - Month (sine/cosine encoded)

### Hyperparameters
```python
{
    'n_estimators': 301,
    'max_depth': 6,
    'min_samples_leaf': 4,
    'min_samples_split': 3,
    'max_features': 'sqrt',
    'bootstrap': True
}
```

## 📁 Repository Structure

```
AirQualityApp/
├── app/
│   └── tkinterapp.py          # Main Tkinter application
├── data/
│   ├── air_quality_global.csv # Primary dataset
│   ├── air_quality_sample.csv # Sample for quick testing
│   └── metadata.json         # Dataset documentation
├── models/
│   ├── best_model_pm25.joblib # Trained RandomForest
│   └── random_forest_pm25_metadata.json # Model info
├── notebooks/
│   ├── data_ingestion.ipynb   # Data processing
│   ├── EDA.ipynb             # Exploratory analysis
│   └── preprocessing_model.ipynb # Model training
├── assets/
│   ├── EDA_summary.txt       # Analysis findings
│   └── model_metrics.csv     # Performance metrics
├── requirements.txt          # Python dependencies
└── README.md                # This documentation
```

---

## 🚀 How to Run

### Setup Environment
```powershell
# Create and activate virtual environment
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt
```

### Launch Application
```powershell
# Run the Tkinter GUI
python app/tkinterapp.py
```

## 🛠️ Technical Details

### Dependencies
- **Core:**
  - Python 3.8+
  - tkinter (included with Python)
  - pandas, numpy
  - scikit-learn=1.5.1
  - joblib

- **Visualization:**
  - matplotlib
  - seaborn

- **Optional:**
  - geopandas (for maps)
  - shap (for deeper feature explanations)

### Quality Controls
- Data validation on load
- Graceful fallback to sample dataset
- Automated feature preparation
- Clear error dialogs

### Data Processing
- **Missing Values:** Median imputation for NO2, validation for coordinates
- **Feature Engineering:**
  - Cyclical encoding for months (sin/cos)
  - Binary country indicators
  - Geographic coordinate normalization

---

## Usage Notes & UI Overview

- Data Controls tab:
  - Load the dataset (or sample) and inspect the first/last rows.
  - Filter by country, city, year, or month.

- EDA tab:
  - Histogram of PM2.5 values.
  - Time series plot of mean PM2.5 over time for selected city/country.
  - Scatter/map (latitude vs longitude) colored by PM2.5.

- Model tab:
  - Load the pre-trained model (`models/best_model_pm25.joblib`).
  - View evaluation metrics (RMSE, MAE, R^2) from `assets/model_metrics.csv` if present.
  - Feature importance bar chart for explainability.
  - Custom prediction form: enter `latitude`, `longitude`, `year`, `month`, `no2_ugm3`, and other required features to get a PM2.5 prediction.

- About / Metadata tab:
  - Displays `data/metadata.json` and `models/random_forest_pm25_metadata.json` for quick reference.

---

## Model & Explainability

- Trained model: RandomForestRegressor (joblib serialized): `models/best_model_pm25.joblib`.
- Model metadata: `models/random_forest_pm25_metadata.json` — contains feature order, training date, and hyperparameters used.
- Explainability: the app computes and plots feature importances from the Random Forest model. For deeper explanations, integrate SHAP (optional).

---

## Troubleshooting

- If `air_quality_global.csv` is missing, the app will attempt to load `data/air_quality_sample.csv` for demo runs. If both are missing, it will show a clear error dialog.
- GUI display issues on Windows: ensure the active Python environment matches the installed packages and try running `python -m pip install --upgrade pip` then reinstall the requirements.
- If model loading fails, check that `joblib` version used matches runtime scikit-learn compatibility.

---

## Development & Extensibility

- To retrain or improve the model, use the notebooks in `notebooks/` (`preprocessing_model.ipynb`) as the starting point.
- Add unit tests for model input preprocessing and prediction functions to increase robustness.

Recommended quick dev cycle:

```powershell
# activate venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m pip install pytest
pytest
```

---

## License

This project and included scripts are released under the MIT License unless otherwise specified. The dataset itself is CC0 1.0 (Public Domain) — see `data/metadata.json` for dataset licensing statements.

---

## Contact

If you have questions or want to contribute, open an issue or contact the repository owner.

---

## Short Checklist (what this README covers)

- Dataset & metadata location — checked ✅
- App features & UI layout — checked ✅
- Model files & explainability — checked ✅
- How to run & dependency install — checked ✅
- Troubleshooting & development notes — checked ✅
