// Enhanced scripts.js with dynamic chart updates
(() => {
  const API_ROOT = (location.hostname === "localhost" || location.hostname === "127.0.0.1") ? "http://127.0.0.1:5000" : "";

  // Set year
  const yEl = document.getElementById('year');
  if (yEl) yEl.textContent = new Date().getFullYear();

  // Dark mode persistence
  const body = document.body;
  const DM_KEY = 'aqx_dark';
  
  function applyDarkMode(enabled){
    if (enabled) body.classList.add('dark'); 
    else body.classList.remove('dark');
    try { localStorage.setItem(DM_KEY, enabled ? '1' : '0'); } catch(e){}
    
    // Update chart if it exists
    if (window.aqxTimeseriesChart) {
      updateChartTheme(window.aqxTimeseriesChart, enabled);
    }
  }
  
  const dm = localStorage.getItem(DM_KEY) === '1';
  applyDarkMode(dm);
  
  const toggleBtns = document.querySelectorAll('#dark-mode-toggle, #dark-mode-toggle-2');
  toggleBtns.forEach(b => b && b.addEventListener('click', () => applyDarkMode(!body.classList.contains('dark'))));

  function updateChartTheme(chart, isDark) {
    const gridColor = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';
    const textColor = isDark ? '#e5e7eb' : '#0b1b2b';
    
    chart.options.scales.x.grid.color = gridColor;
    chart.options.scales.y.grid.color = gridColor;
    chart.options.scales.x.ticks.color = textColor;
    chart.options.scales.y.ticks.color = textColor;
    chart.options.plugins.legend.labels.color = textColor;
    
    chart.update();
  }

  // ---- Auth forms ----
  const loginForm = document.getElementById('login-form');
  if (loginForm){
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = document.getElementById('login-email')?.value || '';
      const password = document.getElementById('login-password')?.value || '';
      
      try {
        const res = await fetch(API_ROOT + '/api/login', {
          method: 'POST', 
          headers: {'Content-Type': 'application/json'}, 
          body: JSON.stringify({email, password})
        });
        const jo = await res.json();
        
        if (jo.ok){
          localStorage.setItem('aqx_token', jo.token);
          localStorage.setItem('aqx_user', JSON.stringify(jo.user));
          window.location.href = 'dashboard.html';
        } else {
          alert(jo.error || 'Login failed');
        }
      } catch (err){
        alert('Server error. Is backend running?');
        console.error(err);
      }
    });
  }

  const registerForm = document.getElementById('register-form');
  if (registerForm){
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(registerForm);
      const payload = {
        fname: fd.get('fname'),
        lname: fd.get('lname'),
        email: fd.get('email'),
        password: fd.get('password')
      };
      
      if (fd.get('password') !== fd.get('confirm')){
        alert('Passwords do not match.');
        return;
      }
      
      try {
        const res = await fetch(API_ROOT + '/api/register', {
          method: 'POST', 
          headers: {'Content-Type': 'application/json'}, 
          body: JSON.stringify(payload)
        });
        const jo = await res.json();
        
        if (jo.ok){
          alert('Registered successfully! Redirecting to login.');
          window.location.href = 'login.html';
        } else {
          alert(jo.error || 'Registration failed');
        }
      } catch (err){
        alert('Server error. Is backend running?');
      }
    });
  }

  // ---- Dashboard sidebar nav ----
  const sidebar = document.getElementById('sidebar');
  const sidebarToggle = document.getElementById('sidebar-toggle');
  sidebarToggle && sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  
  const navLinks = document.querySelectorAll('[data-page]');
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      document.querySelectorAll('.page').forEach(p => p.style.display = 'none');
      navLinks.forEach(n => n.classList.remove('active'));
      link.classList.add('active');
      
      const el = document.querySelector('#page-' + page);
      if (el) el.style.display = '';
      if (sidebar && sidebar.classList.contains('open')) sidebar.classList.remove('open');
    });
  });

  // ---- Dashboard logout ----
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem('aqx_token');
      localStorage.removeItem('aqx_user');
      window.location.href = 'index.html';
    });
  }

  // ---- Update signed-in user display ----
  const signedUserEl = document.getElementById('signed-user');
  if (signedUserEl) {
    try {
      const user = JSON.parse(localStorage.getItem('aqx_user') || '{}');
      if (user.email) {
        signedUserEl.textContent = user.email;
      }
    } catch(e) {}
  }

  // ---- Time series chart ----
  let timeseriesChart = null;
  
  async function loadTimeseriesChart() {
    const tsCanvas = document.getElementById('chart-timeseries');
    if (!tsCanvas || typeof Chart === 'undefined') return;
    
    // Set explicit canvas dimensions to prevent expansion
    const parentWidth = tsCanvas.parentElement.offsetWidth;
    tsCanvas.style.width = '100%';
    tsCanvas.style.height = '300px';
    tsCanvas.width = parentWidth;
    tsCanvas.height = 300;
    
    try {
      const res = await fetch(API_ROOT + '/api/timeseries_data');
      const jo = await res.json();
      
      if (!jo.ok || !jo.timeseries) {
        // Use demo data if no real data
        createDemoChart(tsCanvas);
        return;
      }
      
      // Get time series data
      const timeseries = jo.timeseries;
      const isDark = body.classList.contains('dark');
      
      // Prepare datasets
      const datasets = [];
      const colors = [
        'rgba(255, 99, 132, 0.8)',
        'rgba(54, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',
        'rgba(75, 192, 192, 0.8)',
        'rgba(153, 102, 255, 0.8)',
        'rgba(255, 159, 64, 0.8)'
      ];
      
      let allLabels = [];
      let colorIndex = 0;
      
      // Take top 5 cities by data points
      const sortedCities = Object.keys(timeseries).sort((a, b) => {
        return (timeseries[b].values?.length || 0) - (timeseries[a].values?.length || 0);
      }).slice(0, 5);
      
      sortedCities.forEach(city => {
        const cityData = timeseries[city];
        if (cityData.labels && cityData.values && cityData.values.length > 0) {
          // Merge labels
          cityData.labels.forEach(label => {
            if (!allLabels.includes(label)) {
              allLabels.push(label);
            }
          });
          
          datasets.push({
            label: city,
            data: cityData.values,
            borderColor: colors[colorIndex % colors.length],
            backgroundColor: colors[colorIndex % colors.length].replace('0.8', '0.2'),
            tension: 0.4,
            fill: true,
            pointRadius: 3,
            pointHoverRadius: 5
          });
          colorIndex++;
        }
      });
      
      // Sort labels chronologically
      allLabels.sort();
      
      // If we have a chart, destroy it
      if (timeseriesChart) {
        timeseriesChart.destroy();
      }
      
      const ctx = tsCanvas.getContext('2d');
      timeseriesChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: allLabels,
          datasets: datasets
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: {
            mode: 'index',
            intersect: false
          },
          plugins: {
            legend: {
              position: 'top',
              labels: {
                color: isDark ? '#e5e7eb' : '#0b1b2b',
                usePointStyle: true,
                padding: 15
              }
            },
            tooltip: {
              backgroundColor: isDark ? 'rgba(30, 41, 59, 0.95)' : 'rgba(255, 255, 255, 0.95)',
              titleColor: isDark ? '#e5e7eb' : '#0b1b2b',
              bodyColor: isDark ? '#e5e7eb' : '#0b1b2b',
              borderColor: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
              borderWidth: 1,
              padding: 12,
              displayColors: true,
              callbacks: {
                label: function(context) {
                  let label = context.dataset.label || '';
                  if (label) {
                    label += ': ';
                  }
                  if (context.parsed.y !== null) {
                    label += context.parsed.y.toFixed(2) + ' µg/m³';
                  }
                  return label;
                }
              }
            }
          },
          scales: {
            x: {
              grid: {
                color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                drawBorder: false
              },
              ticks: {
                color: isDark ? '#e5e7eb' : '#0b1b2b',
                maxRotation: 45,
                minRotation: 0
              }
            },
            y: {
              beginAtZero: false,
              grid: {
                color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
                drawBorder: false
              },
              ticks: {
                color: isDark ? '#e5e7eb' : '#0b1b2b',
                callback: function(value) {
                  return value.toFixed(0) + ' µg/m³';
                }
              }
            }
          }
        }
      });
      
      window.aqxTimeseriesChart = timeseriesChart;
      
    } catch (err) {
      console.error('Error loading time series:', err);
      createDemoChart(tsCanvas);
    }
  }
  
  function createDemoChart(canvas) {
    if (timeseriesChart) {
      timeseriesChart.destroy();
    }
    
    const isDark = body.classList.contains('dark');
    const ctx = canvas.getContext('2d');
    const labels = ['2020-01', '2020-06', '2021-01', '2021-06', '2022-01', '2022-06', '2023-01', '2023-06', '2024-01'];
    
    timeseriesChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          { 
            label: 'New Delhi (PM2.5)', 
            data: [120, 110, 130, 115, 100, 95, 105, 98, 92], 
            tension: 0.4, 
            fill: true,
            borderColor: 'rgba(255, 99, 132, 0.8)',
            backgroundColor: 'rgba(255, 99, 132, 0.2)'
          },
          { 
            label: 'Beijing (PM2.5)', 
            data: [90, 85, 95, 80, 78, 72, 75, 70, 68], 
            tension: 0.4, 
            fill: true,
            borderColor: 'rgba(54, 162, 235, 0.8)',
            backgroundColor: 'rgba(54, 162, 235, 0.2)'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { 
          legend: { 
            position: 'top',
            labels: {
              color: isDark ? '#e5e7eb' : '#0b1b2b'
            }
          } 
        },
        scales: { 
          x: {
            grid: { color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' },
            ticks: { color: isDark ? '#e5e7eb' : '#0b1b2b' }
          },
          y: { 
            beginAtZero: false,
            grid: { color: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)' },
            ticks: { color: isDark ? '#e5e7eb' : '#0b1b2b' }
          }
        }
      }
    });
    
    window.aqxTimeseriesChart = timeseriesChart;
  }

  // ---- CSV upload / preview ----
  const uploadBtn = document.getElementById('upload-csv-btn');
  const csvInput = document.getElementById('csv-file');
  const uploadStatus = document.getElementById('upload-status');
  const previewHead = document.getElementById('preview-head');
  const previewBody = document.getElementById('preview-body');
  const previewRowsSelect = document.getElementById('preview-rows');
  const refreshPreviewBtn = document.getElementById('refresh-preview');
  const datasetInfo = document.getElementById('dataset-info');

  async function fetchPreview(rows = 10){
    try {
      const res = await fetch(API_ROOT + '/api/data_preview?rows=' + (rows||10));
      const jo = await res.json();
      
      if (!jo.ok) {
        previewHead.innerHTML = ''; 
        previewBody.innerHTML = '';
        datasetInfo.textContent = jo.error || '';
        return;
      }
      
      const data = jo.data || [];
      if (data.length === 0){
        previewHead.innerHTML = ''; 
        previewBody.innerHTML = '';
        datasetInfo.textContent = 'No data loaded.';
        return;
      }
      
      datasetInfo.textContent = '';
      const keys = Object.keys(data[0]);
      previewHead.innerHTML = '<tr>' + keys.map(k => `<th class="text-nowrap">${k}</th>`).join('') + '</tr>';
      previewBody.innerHTML = data.map(row => 
        '<tr>' + keys.map(k => `<td>${String(row[k]).slice(0,120)}</td>`).join('') + '</tr>'
      ).join('');
    } catch (err){
      console.error(err);
      previewHead.innerHTML = ''; 
      previewBody.innerHTML = '';
      datasetInfo.textContent = 'Preview error (server unreachable?)';
    }
  }

  if (refreshPreviewBtn) {
    refreshPreviewBtn.addEventListener('click', () => {
      const r = parseInt(previewRowsSelect?.value || 10);
      fetchPreview(r);
    });
  }

  if (uploadBtn){
    uploadBtn.addEventListener('click', async () => {
      if (!csvInput || !csvInput.files || csvInput.files.length === 0){
        alert('Choose a CSV file first.');
        return;
      }
      
      const file = csvInput.files[0];
      const form = new FormData();
      form.append('file', file);
      uploadStatus.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2"></i>Uploading and training model...';
      
      try {
        const res = await fetch(API_ROOT + '/api/upload_csv', { method: 'POST', body: form });
        const jo = await res.json();
        
        if (!jo.ok){
          uploadStatus.innerHTML = `<span class="text-danger">${jo.error || 'Upload failed'}</span>`;
          return;
        }
        
        let statusMsg = `<span class="text-success"><i class="fa-solid fa-check me-1"></i>Uploaded successfully!</span><br>`;
        statusMsg += `<small>${jo.meta.rows} rows · ${jo.meta.cols} columns</small><br>`;
        
        if (jo.meta.pollutant_col) {
          statusMsg += `<small>Pollutant: ${jo.meta.pollutant_col}</small><br>`;
        }
        
        if (jo.meta.model_trained) {
          const metrics = jo.meta.model_metrics || {};
          statusMsg += `<small class="text-success">✓ ML Model trained (R²: ${(metrics.r2 || 0).toFixed(3)})</small>`;
        } else if (jo.meta.model_error) {
          statusMsg += `<small class="text-warning">⚠ Model training: ${jo.meta.model_error}</small>`;
        }
        
        uploadStatus.innerHTML = statusMsg;
        
        // Update preview
        const preview = jo.preview || [];
        if (preview.length){
          const keys = Object.keys(preview[0]);
          previewHead.innerHTML = '<tr>' + keys.map(k => `<th class="text-nowrap">${k}</th>`).join('') + '</tr>';
          previewBody.innerHTML = preview.map(row => 
            '<tr>' + keys.map(k => `<td>${String(row[k]).slice(0,120)}</td>`).join('') + '</tr>'
          ).join('');
        }
        
        // Reload time series chart
        await loadTimeseriesChart();
        
        // Update city dropdown in prediction form
        if (jo.meta.cities && jo.meta.cities.length > 0) {
          await updateCityDropdowns(jo.meta.cities);
        }
        
        // Update KPI
        const kRec = document.getElementById('kpi-records');
        if (kRec) {
          kRec.textContent = jo.meta.rows.toLocaleString();
        }
        
      } catch (err){
        console.error(err);
        uploadStatus.innerHTML = '<span class="text-danger">Upload failed (server unreachable?)</span>';
      }
    });
  }

  async function updateCityDropdowns(cities) {
    const predictCitySelect = document.getElementById('predict-city');
    const cityFilterSelect = document.getElementById('city-select');
    
    if (predictCitySelect) {
      predictCitySelect.innerHTML = cities.map(city => 
        `<option value="${city}">${city}</option>`
      ).join('');
    }
    
    if (cityFilterSelect) {
      cityFilterSelect.innerHTML = '<option value="all">All cities</option>' + 
        cities.map(city => `<option value="${city}">${city}</option>`).join('');
    }
  }

  // ---- Prediction form ----
  const predictForm = document.getElementById('predict-form');
  if (predictForm){
    predictForm.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      
      const city = document.getElementById('predict-city').value;
      const date = document.getElementById('predict-date').value || '';
      
      if (!city || !date){
        alert('Provide city and date (YYYY-MM).');
        return;
      }
      
      // Show loading state
      const outputDiv = document.getElementById('prediction-output');
      outputDiv.style.display = '';
      document.getElementById('pred-value').innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Predicting...';
      
      try {
        const res = await fetch(API_ROOT + '/api/predict', {
          method: 'POST', 
          headers: {'Content-Type': 'application/json'}, 
          body: JSON.stringify({city, date})
        });
        const jo = await res.json();
        
        if (!jo.ok){
          alert(jo.error || 'Prediction error');
          outputDiv.style.display = 'none';
          return;
        }
        
        document.getElementById('pred-city-name').textContent = city;
        document.getElementById('pred-date').textContent = date;
        document.getElementById('pred-value').textContent = `${jo.prediction} ${jo.units || 'µg/m³'}`;
        document.getElementById('pred-confidence').textContent = jo.confidence || '';
        
        // Add model type badge if available
        if (jo.model_type) {
          const badge = jo.model_type.includes('ML') ? 
            '<span class="badge bg-success ms-2">ML Model</span>' : 
            '<span class="badge bg-info ms-2">Aggregate</span>';
          document.getElementById('pred-value').innerHTML += badge;
        }
        
      } catch (err){
        console.error(err);
        alert('Prediction request failed (server unreachable?)');
        outputDiv.style.display = 'none';
      }
    });
  }

  // ---- Initialize on dashboard load ----
  if (document.querySelector('#page-overview')) {
    // Load time series chart
    loadTimeseriesChart();
    
    // Load dataset meta and update KPI
    (async () => {
      try {
        const metaRes = await fetch(API_ROOT + '/api/dataset_meta');
        const metaJ = await metaRes.json();
        if (metaJ.ok && metaJ.meta) {
          const kRec = document.getElementById('kpi-records');
          if (kRec) {
            kRec.textContent = metaJ.meta.rows.toLocaleString();
          }
        }
        
        // Load cities
        const citiesRes = await fetch(API_ROOT + '/api/cities');
        const citiesJ = await citiesRes.json();
        if (citiesJ.ok && citiesJ.cities) {
          await updateCityDropdowns(citiesJ.cities);
        }
      } catch(e) { 
        console.log('No dataset loaded yet'); 
      }
    })();
  }

  // ---- Initialize on explorer page ----
  if (document.querySelector('#page-explorer')) {
    (async () => {
      try {
        await fetchPreview(parseInt(previewRowsSelect?.value || 10));
        const metaRes = await fetch(API_ROOT + '/api/dataset_meta');
        const metaJ = await metaRes.json();
        if (metaJ.ok && metaJ.meta) {
          datasetInfo.textContent = `${metaJ.meta.filename} · ${metaJ.meta.rows} rows`;
        }
      } catch(e){ /* ignore */ }
    })();
  }

  // ---- Filter functionality ----
  const applyFiltersBtn = document.getElementById('apply-filters');
  if (applyFiltersBtn) {
    applyFiltersBtn.addEventListener('click', async () => {
      const cityFilter = document.getElementById('city-select')?.value || 'all';
      const dateRange = document.getElementById('date-range')?.value || '';
      
      // Reload chart with filters (you can enhance this)
      await loadTimeseriesChart();
      
      alert(`Filters applied: City=${cityFilter}, Date=${dateRange || 'all'}`);
    });
  }

})();