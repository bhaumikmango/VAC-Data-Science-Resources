# 🌍 Air Quality Prediction Web App

### 📊 Intelligent Air Quality Dashboard using Machine Learning and Flask

This project is a full-stack web application that predicts **air quality levels (PM2.5, AQI, etc.)** based on historical urban data.
It provides **interactive charts, CSV upload functionality, and model-based forecasting** — all integrated with a clean, responsive UI.

---

## 🚀 Features

✅ **Data Upload & Preview**

* Upload CSV datasets containing air quality metrics.
* Preview tabular data directly in the dashboard.

✅ **Machine Learning Integration**

* Trains an ML regression model automatically upon CSV upload.
* Supports city- and date-based predictions using trained models.

✅ **Dynamic Prediction Graphs**

* Displays interactive line charts of predicted air quality trends.
* Automatically adjusts chart themes for dark/light mode.

✅ **Dark Mode Support**

* Persistent dark theme stored in browser local storage.

✅ **User Authentication**

* Secure registration & login system (Flask + SQLite).
* Session token storage for logged-in users.

✅ **Responsive Dashboard**

* Organized pages: Overview, Explorer, Prediction.
* Sidebar navigation with collapsible menu.

✅ **Error Handling**

* Robust backend validation for CSVs, empty files, or missing columns.
* Frontend shows clear status/error messages.

---

## 🧩 Project Structure

```
AirQualityApp/
│
├── app.py                 # Flask backend (API + ML training/prediction)
├── app.db                 # SQLite database for users & session storage
├── trained_model.pkl      # Saved trained model (generated after upload)
│
├── static/
│   ├── style.css          # Unified dark/light theme styling
│   ├── script.js          # Frontend logic & chart control
│   ├── assets/            # (optional) Icons / images
│
├── templates/
│   ├── index.html         # Landing page
│   ├── login.html         # Login page
│   ├── register.html      # Registration page
│   ├── dashboard.html     # Main dashboard with charts & predictions
│
├── uploads/               # Uploaded CSVs
│
├── metadata.json          # Dataset metadata (columns, source info)
├── requirements.txt       # Python dependencies
└── README.md              # (this file)
```

---

## 🧠 How It Works

1. **CSV Upload:**

   * The user uploads a CSV containing columns like `City`, `Date`, and `PM2.5`.
   * The backend parses the file, performs feature extraction, and trains an ML model.

2. **Model Training:**

   * A regression model (e.g. `RandomForestRegressor`) is trained on the uploaded dataset.
   * The trained model is stored as `trained_model.pkl`.

3. **Prediction:**

   * The user selects a city and a date.
   * The backend loads the saved model, predicts air quality, and returns JSON data.

4. **Visualization:**

   * The frontend uses Chart.js to render the returned predictions as dynamic charts.
   * Old charts are destroyed before rendering new data to prevent chart expansion.

---

## 🧾 Example Workflow

1. **Register/Login**
   → Access the dashboard.
2. **Upload a CSV**
   → The app reads it and trains a model.
3. **Preview the Data**
   → Shows top rows in a clean table.
4. **Select City + Date**
   → App predicts the AQI or PM2.5 for that input.
5. **See Prediction Graph**
   → Interactive, themed chart appears instantly.

---

## 🛡️ Troubleshooting

| Problem                              | Cause                 | Fix                                                     |
| ------------------------------------ | --------------------- | ------------------------------------------------------- |
| `source venv/bin/activate` not found | Windows shell syntax  | Use `.\\venv\\Scripts\\Activate.ps1`                    |
| Flask `ModuleNotFoundError`          | Missing Flask package | Run `pip install Flask Flask-Cors`                      |
| Graph keeps expanding                | Chart.js not reset    | Fixed in updated `script.js` (chart.destroy() + reinit) |
| Upload fails                         | File not valid CSV    | Ensure CSV has headers like `City, Date, PM2.5`         |
| No prediction visible                | Model not trained     | Re-upload dataset with valid numeric columns            |

---

## 💡 Technologies Used

* **Backend:** Flask (Python), SQLite, scikit-learn
* **Frontend:** HTML5, CSS3, Vanilla JS, Chart.js
* **Data Handling:** pandas, numpy
* **Model Serialization:** joblib
* **Version Control:** Git / GitHub

---

## 🧪 Example Dataset Format

| City   | Date    | PM2.5 | Temp | Humidity |
| ------ | ------- | ----- | ---- | -------- |
| Delhi  | 2020-01 | 120   | 25.3 | 35.2     |
| Delhi  | 2020-02 | 110   | 27.1 | 32.1     |
| Mumbai | 2020-01 | 90    | 29.4 | 45.0     |

---

## 📈 ML Model Used

By default, the backend uses a **Random Forest Regressor**, trained on uploaded CSVs.
Evaluation metrics such as **R², MSE, and MAE** are logged and displayed in the dashboard.

You can replace the model by editing this section in `app.py`:

```python
from sklearn.ensemble import RandomForestRegressor
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
```

---

## 🌐 API Endpoints Summary

| Endpoint               | Method | Description                       |
| ---------------------- | ------ | --------------------------------- |
| `/api/register`        | POST   | Register new user                 |
| `/api/login`           | POST   | Authenticate user                 |
| `/api/upload_csv`      | POST   | Upload dataset and train model    |
| `/api/predict`         | POST   | Predict air quality for city/date |
| `/api/timeseries_data` | GET    | Retrieve chart data               |
| `/api/data_preview`    | GET    | Preview uploaded dataset          |
| `/api/dataset_meta`    | GET    | Retrieve metadata info            |

---

## 👨‍💻 Author

**Project by:**
**Shivam Pratap Singh**
B.Tech (AKTU) — CSE(AI&ML)

---

## 🧾 License

MIT License © 2025 Shivam Pratap Singh

You are free to modify and distribute this code for educational and non-commercial purposes.


