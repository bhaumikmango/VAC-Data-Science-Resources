import os
import sqlite3
import pickle
import numpy as np
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
from datetime import datetime
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, r2_score
import warnings
warnings.filterwarnings('ignore')

UPLOAD_FOLDER = "uploads"
MODEL_FOLDER = "models"
DB_FILE = "app.db"
ALLOWED_EXTENSIONS = {"csv"}

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(MODEL_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MODEL_FOLDER"] = MODEL_FOLDER
CORS(app, origins="*")

# ---- Database helpers ----
def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fname TEXT,
        lname TEXT,
        email TEXT UNIQUE,
        password_hash TEXT,
        created_at TEXT
    )
    """)
    cur.execute("""
    CREATE TABLE IF NOT EXISTS dataset_meta (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        filename TEXT,
        uploaded_at TEXT,
        rows INTEGER,
        cols INTEGER
    )
    """)
    conn.commit()
    conn.close()

init_db()

# ---- Utilities ----
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

DATA_CACHE = {
    'df': None,
    'city_col': None,
    'date_col': None,
    'pollutant_col': None,
    'aggregates': {},
    'global_mean': None,
    'model': None,
    'label_encoders': {},
    'feature_cols': [],
    'timeseries_data': {},
    'cities': [],
    'model_metrics': {}
}

def find_column(df, possible_names):
    """Find column by possible names (case-insensitive)"""
    df_cols_lower = {c.lower(): c for c in df.columns}
    for name in possible_names:
        if name.lower() in df_cols_lower:
            return df_cols_lower[name.lower()]
    return None

def prepare_features(df, city_col, date_col, pollutant_col):
    """Prepare features for ML model"""
    df_ml = df.copy()
    
    # Parse dates
    if date_col:
        df_ml['_parsed_date'] = pd.to_datetime(df_ml[date_col], errors='coerce')
        df_ml = df_ml.dropna(subset=['_parsed_date'])
        
        # Extract date features
        df_ml['year'] = df_ml['_parsed_date'].dt.year
        df_ml['month'] = df_ml['_parsed_date'].dt.month
        df_ml['day'] = df_ml['_parsed_date'].dt.day
        df_ml['day_of_week'] = df_ml['_parsed_date'].dt.dayofweek
        df_ml['quarter'] = df_ml['_parsed_date'].dt.quarter
        df_ml['day_of_year'] = df_ml['_parsed_date'].dt.dayofyear
    
    # Encode city
    if city_col:
        le_city = LabelEncoder()
        df_ml['city_encoded'] = le_city.fit_transform(df_ml[city_col].astype(str))
        DATA_CACHE['label_encoders']['city'] = le_city
    
    # Clean pollutant column
    if pollutant_col:
        df_ml[pollutant_col] = pd.to_numeric(df_ml[pollutant_col], errors='coerce')
        df_ml = df_ml.dropna(subset=[pollutant_col])
        df_ml = df_ml[df_ml[pollutant_col] > 0]  # Remove negative/zero values
    
    return df_ml

def train_ml_model(df, city_col, date_col, pollutant_col):
    """Train ML model for predictions"""
    try:
        df_ml = prepare_features(df, city_col, date_col, pollutant_col)
        
        if len(df_ml) < 50:
            return None, "Insufficient data for training (need at least 50 records)"
        
        # Define features
        feature_cols = ['year', 'month', 'day', 'day_of_week', 'quarter', 'day_of_year']
        if city_col:
            feature_cols.append('city_encoded')
        
        X = df_ml[feature_cols]
        y = df_ml[pollutant_col]
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42
        )
        
        # Train model (using GradientBoosting for better performance)
        model = GradientBoostingRegressor(
            n_estimators=100,
            learning_rate=0.1,
            max_depth=5,
            random_state=42
        )
        model.fit(X_train, y_train)
        
        # Evaluate
        y_pred = model.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        # Store model and metadata
        DATA_CACHE['model'] = model
        DATA_CACHE['feature_cols'] = feature_cols
        DATA_CACHE['model_metrics'] = {
            'mae': float(mae),
            'r2': float(r2),
            'train_samples': len(X_train),
            'test_samples': len(X_test)
        }
        
        # Save model
        model_path = os.path.join(app.config["MODEL_FOLDER"], "air_quality_model.pkl")
        with open(model_path, 'wb') as f:
            pickle.dump({
                'model': model,
                'feature_cols': feature_cols,
                'label_encoders': DATA_CACHE['label_encoders'],
                'metrics': DATA_CACHE['model_metrics']
            }, f)
        
        return model, None
    except Exception as e:
        return None, str(e)

def compute_timeseries_data(df, city_col, date_col, pollutant_col):
    """Compute time series data for charts"""
    timeseries = {}
    
    if not date_col or not pollutant_col:
        return timeseries
    
    df_ts = df.copy()
    df_ts['_parsed_date'] = pd.to_datetime(df_ts[date_col], errors='coerce')
    df_ts = df_ts.dropna(subset=['_parsed_date'])
    df_ts[pollutant_col] = pd.to_numeric(df_ts[pollutant_col], errors='coerce')
    df_ts = df_ts.dropna(subset=[pollutant_col])
    
    # Create year-month column
    df_ts['year_month'] = df_ts['_parsed_date'].dt.to_period('M').astype(str)
    
    if city_col:
        # Group by city and year-month
        grouped = df_ts.groupby([city_col, 'year_month'])[pollutant_col].mean().reset_index()
        
        for city in grouped[city_col].unique():
            city_data = grouped[grouped[city_col] == city].sort_values('year_month')
            timeseries[str(city)] = {
                'labels': city_data['year_month'].tolist(),
                'values': city_data[pollutant_col].round(2).tolist()
            }
    else:
        # Just group by year-month
        grouped = df_ts.groupby('year_month')[pollutant_col].mean().reset_index()
        grouped = grouped.sort_values('year_month')
        timeseries['overall'] = {
            'labels': grouped['year_month'].tolist(),
            'values': grouped[pollutant_col].round(2).tolist()
        }
    
    return timeseries

def load_uploaded_csv(path):
    """Load and analyze CSV with ML training"""
    try:
        df = pd.read_csv(path, low_memory=False)
    except Exception:
        df = pd.read_csv(path, encoding="utf-8", low_memory=False)
    
    # Normalize column names
    df.columns = [c.strip() for c in df.columns]
    
    # Find columns
    city_col = find_column(df, ["city", "location", "station", "site", "City"])
    date_col = find_column(df, ["date", "datetime", "timestamp", "time", "Date"])
    pm25_col = find_column(df, ["pm2.5", "pm25", "pm_2_5", "pm_2.5", "PM2.5"])
    no2_col = find_column(df, ["no2", "n02", "nitrogen_dioxide", "NO2"])
    
    # Choose pollutant
    pollutant_col = None
    if pm25_col:
        pollutant_col = pm25_col
    elif no2_col:
        pollutant_col = no2_col
    else:
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        pollutant_col = numeric_cols[0] if numeric_cols else None
    
    # Compute aggregates
    aggregates = {}
    global_mean = None
    
    if pollutant_col:
        df[pollutant_col] = pd.to_numeric(df[pollutant_col], errors='coerce')
        global_mean = float(df[pollutant_col].dropna().mean()) if not df[pollutant_col].dropna().empty else None
        
        if date_col:
            df['_parsed_date'] = pd.to_datetime(df[date_col], errors='coerce')
            df['_ym'] = df['_parsed_date'].dt.to_period('M').astype(str).fillna('unknown')
            
            if city_col:
                grouped = df.groupby([city_col, '_ym'], dropna=True)[pollutant_col].mean().reset_index()
                for _, row in grouped.iterrows():
                    key = (str(row[city_col]).strip(), str(row['_ym']))
                    aggregates[key] = float(row[pollutant_col]) if pd.notna(row[pollutant_col]) else None
    
    # Get unique cities
    cities = []
    if city_col:
        cities = sorted(df[city_col].dropna().unique().tolist())
    
    # Compute time series data
    timeseries_data = compute_timeseries_data(df, city_col, date_col, pollutant_col)
    
    # Train ML model
    model, error = train_ml_model(df, city_col, date_col, pollutant_col)
    
    # Store in cache
    DATA_CACHE['df'] = df
    DATA_CACHE['city_col'] = city_col
    DATA_CACHE['date_col'] = date_col
    DATA_CACHE['pollutant_col'] = pollutant_col
    DATA_CACHE['aggregates'] = aggregates
    DATA_CACHE['global_mean'] = global_mean
    DATA_CACHE['timeseries_data'] = timeseries_data
    DATA_CACHE['cities'] = cities
    
    return {
        'rows': int(df.shape[0]),
        'cols': int(df.shape[1]),
        'city_col': city_col,
        'date_col': date_col,
        'pollutant_col': pollutant_col,
        'global_mean': global_mean,
        'cities': cities[:20],  # Return first 20 cities
        'model_trained': model is not None,
        'model_error': error,
        'model_metrics': DATA_CACHE.get('model_metrics', {})
    }

# ---- Auth endpoints ----
@app.route("/api/register", methods=["POST"])
def api_register():
    data = request.get_json(force=True)
    fname = data.get("fname", "").strip()
    lname = data.get("lname", "").strip()
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"ok": False, "error": "Email and password required."}), 400

    pwd_hash = generate_password_hash(password)
    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute("INSERT INTO users (fname, lname, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?)",
                    (fname, lname, email, pwd_hash, datetime.utcnow().isoformat()))
        conn.commit()
        return jsonify({"ok": True, "message": "Registered."})
    except sqlite3.IntegrityError:
        return jsonify({"ok": False, "error": "Email already registered."}), 400
    finally:
        conn.close()

@app.route("/api/login", methods=["POST"])
def api_login():
    data = request.get_json(force=True)
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"ok": False, "error": "Email and password required."}), 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE email = ?", (email,))
    row = cur.fetchone()
    conn.close()
    
    if not row:
        return jsonify({"ok": False, "error": "Invalid credentials."}), 401

    if not check_password_hash(row["password_hash"], password):
        return jsonify({"ok": False, "error": "Invalid credentials."}), 401

    token = f"demo-token-{row['id']}"
    return jsonify({
        "ok": True, 
        "token": token, 
        "user": {
            "id": row["id"], 
            "email": row["email"], 
            "fname": row["fname"], 
            "lname": row["lname"]
        }
    })

# ---- CSV upload & preview ----
@app.route("/api/upload_csv", methods=["POST"])
def api_upload_csv():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "No file part"}), 400
    
    file = request.files["file"]
    if file.filename == "":
        return jsonify({"ok": False, "error": "No selected file"}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(save_path)

        # Load and analyze
        meta = load_uploaded_csv(save_path)

        # Store metadata in db
        conn = get_db()
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO dataset_meta (id, filename, uploaded_at, rows, cols) VALUES (1, ?, ?, ?, ?)",
                    (filename, datetime.utcnow().isoformat(), meta["rows"], meta["cols"]))
        conn.commit()
        conn.close()

        # Preview data
        preview = []
        df = DATA_CACHE.get("df")
        if df is not None:
            preview = df.head(10).fillna("").to_dict(orient="records")

        return jsonify({
            "ok": True,
            "meta": meta,
            "preview": preview
        })
    else:
        return jsonify({"ok": False, "error": "Invalid file type"}), 400

@app.route("/api/data_preview", methods=["GET"])
def api_data_preview():
    df = DATA_CACHE.get("df")
    if df is None:
        return jsonify({"ok": False, "error": "No dataset uploaded"}), 404
    
    rows = int(request.args.get("rows", 20))
    data = df.head(rows).fillna("").to_dict(orient="records")
    return jsonify({"ok": True, "data": data})

@app.route("/api/dataset_meta", methods=["GET"])
def api_dataset_meta():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM dataset_meta WHERE id=1")
    row = cur.fetchone()
    conn.close()
    
    if not row:
        return jsonify({"ok": False, "error": "No dataset uploaded"}), 404
    
    return jsonify({"ok": True, "meta": dict(row)})

@app.route("/api/timeseries_data", methods=["GET"])
def api_timeseries_data():
    """Get time series data for charts"""
    timeseries = DATA_CACHE.get('timeseries_data', {})
    if not timeseries:
        return jsonify({"ok": False, "error": "No time series data available"}), 404
    
    return jsonify({"ok": True, "timeseries": timeseries})

@app.route("/api/cities", methods=["GET"])
def api_cities():
    """Get list of cities from dataset"""
    cities = DATA_CACHE.get('cities', [])
    return jsonify({"ok": True, "cities": cities})

@app.route("/api/model_info", methods=["GET"])
def api_model_info():
    """Get ML model information"""
    model = DATA_CACHE.get('model')
    if not model:
        return jsonify({"ok": False, "error": "No model trained"}), 404
    
    metrics = DATA_CACHE.get('model_metrics', {})
    return jsonify({
        "ok": True,
        "model_type": "Gradient Boosting Regressor",
        "metrics": metrics,
        "features": DATA_CACHE.get('feature_cols', [])
    })

# ---- Prediction endpoint ----
@app.route("/api/predict", methods=["POST"])
def api_predict():
    """ML-based prediction endpoint"""
    data = request.get_json(force=True)
    city = (data.get("city") or "").strip()
    date_str = (data.get("date") or "").strip()

    if not city or not date_str:
        return jsonify({"ok": False, "error": "city and date required (format YYYY-MM)."}), 400

    model = DATA_CACHE.get('model')
    
    if model is None:
        # Fallback to aggregate-based prediction
        return fallback_prediction(city, date_str)
    
    try:
        # Parse date
        date_parts = date_str.split('-')
        if len(date_parts) != 2:
            return jsonify({"ok": False, "error": "Date format should be YYYY-MM"}), 400
        
        year = int(date_parts[0])
        month = int(date_parts[1])
        
        # Create feature vector
        day = 15  # Use middle of month
        date_obj = datetime(year, month, day)
        
        features = {
            'year': year,
            'month': month,
            'day': day,
            'day_of_week': date_obj.weekday(),
            'quarter': (month - 1) // 3 + 1,
            'day_of_year': date_obj.timetuple().tm_yday
        }
        
        # Encode city if needed
        if 'city_encoded' in DATA_CACHE.get('feature_cols', []):
            le_city = DATA_CACHE['label_encoders'].get('city')
            if le_city:
                try:
                    features['city_encoded'] = le_city.transform([city])[0]
                except:
                    # City not in training data
                    features['city_encoded'] = 0
        
        # Create feature array
        feature_cols = DATA_CACHE.get('feature_cols', [])
        X = np.array([[features[col] for col in feature_cols]])
        
        # Predict
        prediction = model.predict(X)[0]
        
        # Calculate confidence based on model metrics
        r2 = DATA_CACHE.get('model_metrics', {}).get('r2', 0.5)
        confidence = int(max(50, min(95, r2 * 100)))
        
        return jsonify({
            "ok": True,
            "prediction": round(float(prediction), 2),
            "units": "µg/m³",
            "confidence": f"{confidence}%",
            "model_type": "ML (Gradient Boosting)"
        })
    
    except Exception as e:
        return fallback_prediction(city, date_str)

def fallback_prediction(city, date_str):
    """Fallback prediction using aggregates"""
    aggregates = DATA_CACHE.get("aggregates", {})
    global_mean = DATA_CACHE.get("global_mean")
    
    key = (city, date_str)
    val = aggregates.get(key)
    
    # Try case-insensitive match
    if val is None:
        for (c, ym), v in aggregates.items():
            if c.strip().lower() == city.strip().lower() and ym == date_str:
                val = v
                break
    
    # Try city average
    if val is None:
        city_vals = [v for (c, ym), v in aggregates.items() 
                     if c.strip().lower() == city.strip().lower() and v is not None]
        if city_vals:
            val = float(sum(city_vals) / len(city_vals))
    
    # Use global mean
    if val is None and global_mean is not None:
        val = global_mean
    
    if val is None:
        return jsonify({"ok": False, "error": "Insufficient data for prediction."}), 422
    
    confidence = "60%"
    if (city, date_str) in aggregates:
        confidence = "82%"
    elif any(c.strip().lower() == city.strip().lower() for (c, ym) in aggregates.keys()):
        confidence = "70%"
    
    return jsonify({
        "ok": True,
        "prediction": round(val, 2),
        "units": "µg/m³",
        "confidence": confidence,
        "model_type": "Aggregate-based"
    })

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=True)

@app.route("/api/health")
def health():
    return jsonify({"ok": True, "status": "running"})

if __name__ == "__main__":
    app.run(port=5000, debug=True)